# WordPress MySQL database migration
#
# Generated: Monday 30. May 2016 21:10 UTC
# Hostname: localhost
# Database: `webdesign`
# --------------------------------------------------------

/*!40101 SET NAMES utf8mb4 */;

SET sql_mode='NO_AUTO_VALUE_ON_ZERO';



#
# Delete any existing table `wp_wd_commentmeta`
#

DROP TABLE IF EXISTS `wp_wd_commentmeta`;


#
# Table structure of table `wp_wd_commentmeta`
#

CREATE TABLE `wp_wd_commentmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `comment_id` (`comment_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wd_commentmeta`
#

#
# End of data contents of table `wp_wd_commentmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_wd_comments`
#

DROP TABLE IF EXISTS `wp_wd_comments`;


#
# Table structure of table `wp_wd_comments`
#

CREATE TABLE `wp_wd_comments` (
  `comment_ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `comment_post_ID` bigint(20) unsigned NOT NULL DEFAULT '0',
  `comment_author` tinytext COLLATE utf8_unicode_ci NOT NULL,
  `comment_author_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_url` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_author_IP` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `comment_content` text COLLATE utf8_unicode_ci NOT NULL,
  `comment_karma` int(11) NOT NULL DEFAULT '0',
  `comment_approved` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '1',
  `comment_agent` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`comment_ID`),
  KEY `comment_post_ID` (`comment_post_ID`),
  KEY `comment_approved_date_gmt` (`comment_approved`,`comment_date_gmt`),
  KEY `comment_date_gmt` (`comment_date_gmt`),
  KEY `comment_parent` (`comment_parent`),
  KEY `comment_author_email` (`comment_author_email`(10))
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wd_comments`
#
INSERT INTO `wp_wd_comments` ( `comment_ID`, `comment_post_ID`, `comment_author`, `comment_author_email`, `comment_author_url`, `comment_author_IP`, `comment_date`, `comment_date_gmt`, `comment_content`, `comment_karma`, `comment_approved`, `comment_agent`, `comment_type`, `comment_parent`, `user_id`) VALUES
(1, 1, 'Monsieur WordPress', '', 'https://wordpress.org/', '', '2016-02-23 23:17:56', '2016-02-23 22:17:56', 'Bonjour, ceci est un commentaire.\nPour supprimer un commentaire, connectez-vous et affichez les commentaires de cet article. Vous pourrez alors les modifier ou les supprimer.', 0, '1', '', '', 0, 0) ;

#
# End of data contents of table `wp_wd_comments`
# --------------------------------------------------------



#
# Delete any existing table `wp_wd_links`
#

DROP TABLE IF EXISTS `wp_wd_links`;


#
# Table structure of table `wp_wd_links`
#

CREATE TABLE `wp_wd_links` (
  `link_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `link_url` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_name` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_image` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_target` varchar(25) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_description` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_visible` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'Y',
  `link_owner` bigint(20) unsigned NOT NULL DEFAULT '1',
  `link_rating` int(11) NOT NULL DEFAULT '0',
  `link_updated` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `link_rel` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `link_notes` mediumtext COLLATE utf8_unicode_ci NOT NULL,
  `link_rss` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`link_id`),
  KEY `link_visible` (`link_visible`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wd_links`
#

#
# End of data contents of table `wp_wd_links`
# --------------------------------------------------------



#
# Delete any existing table `wp_wd_options`
#

DROP TABLE IF EXISTS `wp_wd_options`;


#
# Table structure of table `wp_wd_options`
#

CREATE TABLE `wp_wd_options` (
  `option_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `option_name` varchar(191) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `option_value` longtext COLLATE utf8_unicode_ci NOT NULL,
  `autoload` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'yes',
  PRIMARY KEY (`option_id`),
  UNIQUE KEY `option_name` (`option_name`)
) ENGINE=InnoDB AUTO_INCREMENT=1190 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wd_options`
#
INSERT INTO `wp_wd_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(1, 'siteurl', 'http://localhost:8888/blogwebdesign', 'yes'),
(2, 'home', 'http://localhost:8888/blogwebdesign', 'yes'),
(3, 'blogname', 'Flawless webdesign', 'yes'),
(4, 'blogdescription', 'Blog sur le webdesign', 'yes'),
(5, 'users_can_register', '0', 'yes'),
(6, 'admin_email', 'alexandre.kong@gmail.com', 'yes'),
(7, 'start_of_week', '1', 'yes'),
(8, 'use_balanceTags', '0', 'yes'),
(9, 'use_smilies', '1', 'yes'),
(10, 'require_name_email', '1', 'yes'),
(11, 'comments_notify', '1', 'yes'),
(12, 'posts_per_rss', '10', 'yes'),
(13, 'rss_use_excerpt', '0', 'yes'),
(14, 'mailserver_url', 'mail.example.com', 'yes'),
(15, 'mailserver_login', 'login@example.com', 'yes'),
(16, 'mailserver_pass', 'password', 'yes'),
(17, 'mailserver_port', '110', 'yes'),
(18, 'default_category', '1', 'yes'),
(19, 'default_comment_status', 'open', 'yes'),
(20, 'default_ping_status', 'open', 'yes'),
(21, 'default_pingback_flag', '1', 'yes'),
(22, 'posts_per_page', '10', 'yes'),
(23, 'date_format', 'j F Y', 'yes'),
(24, 'time_format', 'G \\h i \\m\\i\\n', 'yes'),
(25, 'links_updated_date_format', 'j F Y G \\h i \\m\\i\\n', 'yes'),
(26, 'comment_moderation', '0', 'yes'),
(27, 'moderation_notify', '1', 'yes'),
(28, 'permalink_structure', '/%postname%/', 'yes'),
(29, 'hack_file', '0', 'yes'),
(30, 'blog_charset', 'UTF-8', 'yes'),
(31, 'moderation_keys', '', 'no'),
(32, 'active_plugins', 'a:5:{i:0;s:37:"ajax-search-lite/ajax-search-lite.php";i:1;s:51:"post-type-archive-links/post-type-archive-links.php";i:2;s:24:"wordpress-seo/wp-seo.php";i:3;s:25:"wp-members/wp-members.php";i:4;s:31:"wp-migrate-db/wp-migrate-db.php";}', 'yes'),
(33, 'category_base', '', 'yes'),
(34, 'ping_sites', 'http://rpc.pingomatic.com/', 'yes'),
(35, 'comment_max_links', '2', 'yes'),
(36, 'gmt_offset', '1', 'yes'),
(37, 'default_email_category', '1', 'yes'),
(38, 'recently_edited', 'a:3:{i:0;s:96:"/Applications/MAMP/htdocs/blogwebdesign/wp-content/plugins/ajax-search-lite/ajax-search-lite.php";i:1;s:77:"/Applications/MAMP/htdocs/blogwebdesign/wp-content/themes/Webdesign/style.css";i:2;s:0:"";}', 'no'),
(39, 'template', 'themewebdesign', 'yes'),
(40, 'stylesheet', 'themewebdesign', 'yes'),
(41, 'comment_whitelist', '1', 'yes'),
(42, 'blacklist_keys', '', 'no'),
(43, 'comment_registration', '0', 'yes'),
(44, 'html_type', 'text/html', 'yes'),
(45, 'use_trackback', '0', 'yes'),
(46, 'default_role', 'subscriber', 'yes'),
(47, 'db_version', '36686', 'yes'),
(48, 'uploads_use_yearmonth_folders', '1', 'yes'),
(49, 'upload_path', '', 'yes'),
(50, 'blog_public', '1', 'yes'),
(51, 'default_link_category', '2', 'yes'),
(52, 'show_on_front', 'posts', 'yes'),
(53, 'tag_base', '', 'yes'),
(54, 'show_avatars', '1', 'yes'),
(55, 'avatar_rating', 'G', 'yes'),
(56, 'upload_url_path', '', 'yes'),
(57, 'thumbnail_size_w', '150', 'yes'),
(58, 'thumbnail_size_h', '150', 'yes'),
(59, 'thumbnail_crop', '1', 'yes'),
(60, 'medium_size_w', '300', 'yes'),
(61, 'medium_size_h', '300', 'yes'),
(62, 'avatar_default', 'mystery', 'yes'),
(63, 'large_size_w', '1024', 'yes'),
(64, 'large_size_h', '1024', 'yes'),
(65, 'image_default_link_type', 'none', 'yes'),
(66, 'image_default_size', '', 'yes'),
(67, 'image_default_align', '', 'yes'),
(68, 'close_comments_for_old_posts', '0', 'yes'),
(69, 'close_comments_days_old', '14', 'yes'),
(70, 'thread_comments', '1', 'yes'),
(71, 'thread_comments_depth', '5', 'yes'),
(72, 'page_comments', '0', 'yes'),
(73, 'comments_per_page', '50', 'yes'),
(74, 'default_comments_page', 'newest', 'yes'),
(75, 'comment_order', 'asc', 'yes'),
(76, 'sticky_posts', 'a:0:{}', 'yes'),
(77, 'widget_categories', 'a:2:{i:2;a:4:{s:5:"title";s:0:"";s:5:"count";i:0;s:12:"hierarchical";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(78, 'widget_text', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(79, 'widget_rss', 'a:2:{i:1;a:0:{}s:12:"_multiwidget";i:1;}', 'yes'),
(80, 'uninstall_plugins', 'a:0:{}', 'no'),
(81, 'timezone_string', '', 'yes'),
(82, 'page_for_posts', '0', 'yes'),
(83, 'page_on_front', '0', 'yes'),
(84, 'default_post_format', '0', 'yes'),
(85, 'link_manager_enabled', '0', 'yes'),
(86, 'finished_splitting_shared_terms', '1', 'yes'),
(87, 'site_icon', '0', 'yes'),
(88, 'medium_large_size_w', '768', 'yes'),
(89, 'medium_large_size_h', '0', 'yes'),
(90, 'initial_db_version', '35700', 'yes'),
(91, 'wp_wd_user_roles', 'a:5:{s:13:"administrator";a:2:{s:4:"name";s:13:"Administrator";s:12:"capabilities";a:62:{s:13:"switch_themes";b:1;s:11:"edit_themes";b:1;s:16:"activate_plugins";b:1;s:12:"edit_plugins";b:1;s:10:"edit_users";b:1;s:10:"edit_files";b:1;s:14:"manage_options";b:1;s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:6:"import";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:8:"level_10";b:1;s:7:"level_9";b:1;s:7:"level_8";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:12:"delete_users";b:1;s:12:"create_users";b:1;s:17:"unfiltered_upload";b:1;s:14:"edit_dashboard";b:1;s:14:"update_plugins";b:1;s:14:"delete_plugins";b:1;s:15:"install_plugins";b:1;s:13:"update_themes";b:1;s:14:"install_themes";b:1;s:11:"update_core";b:1;s:10:"list_users";b:1;s:12:"remove_users";b:1;s:13:"promote_users";b:1;s:18:"edit_theme_options";b:1;s:13:"delete_themes";b:1;s:6:"export";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"editor";a:2:{s:4:"name";s:6:"Editor";s:12:"capabilities";a:35:{s:17:"moderate_comments";b:1;s:17:"manage_categories";b:1;s:12:"manage_links";b:1;s:12:"upload_files";b:1;s:15:"unfiltered_html";b:1;s:10:"edit_posts";b:1;s:17:"edit_others_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:10:"edit_pages";b:1;s:4:"read";b:1;s:7:"level_7";b:1;s:7:"level_6";b:1;s:7:"level_5";b:1;s:7:"level_4";b:1;s:7:"level_3";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:17:"edit_others_pages";b:1;s:20:"edit_published_pages";b:1;s:13:"publish_pages";b:1;s:12:"delete_pages";b:1;s:19:"delete_others_pages";b:1;s:22:"delete_published_pages";b:1;s:12:"delete_posts";b:1;s:19:"delete_others_posts";b:1;s:22:"delete_published_posts";b:1;s:20:"delete_private_posts";b:1;s:18:"edit_private_posts";b:1;s:18:"read_private_posts";b:1;s:20:"delete_private_pages";b:1;s:18:"edit_private_pages";b:1;s:18:"read_private_pages";b:1;s:15:"wpseo_bulk_edit";b:1;}}s:6:"author";a:2:{s:4:"name";s:6:"Author";s:12:"capabilities";a:10:{s:12:"upload_files";b:1;s:10:"edit_posts";b:1;s:20:"edit_published_posts";b:1;s:13:"publish_posts";b:1;s:4:"read";b:1;s:7:"level_2";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;s:22:"delete_published_posts";b:1;}}s:11:"contributor";a:2:{s:4:"name";s:11:"Contributor";s:12:"capabilities";a:5:{s:10:"edit_posts";b:1;s:4:"read";b:1;s:7:"level_1";b:1;s:7:"level_0";b:1;s:12:"delete_posts";b:1;}}s:10:"subscriber";a:2:{s:4:"name";s:10:"Subscriber";s:12:"capabilities";a:2:{s:4:"read";b:1;s:7:"level_0";b:1;}}}', 'yes'),
(92, 'WPLANG', 'fr_FR', 'yes'),
(93, 'widget_search', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(94, 'widget_recent-posts', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(95, 'widget_recent-comments', 'a:2:{i:2;a:2:{s:5:"title";s:0:"";s:6:"number";i:5;}s:12:"_multiwidget";i:1;}', 'yes'),
(96, 'widget_archives', 'a:2:{i:2;a:3:{s:5:"title";s:0:"";s:5:"count";i:0;s:8:"dropdown";i:0;}s:12:"_multiwidget";i:1;}', 'yes'),
(97, 'widget_meta', 'a:2:{i:2;a:1:{s:5:"title";s:0:"";}s:12:"_multiwidget";i:1;}', 'yes'),
(98, 'sidebars_widgets', 'a:4:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:14:"footer-widgets";N;s:13:"array_version";i:3;}', 'yes'),
(100, 'widget_pages', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(101, 'widget_calendar', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_wd_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(102, 'widget_tag_cloud', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(103, 'widget_nav_menu', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(104, 'cron', 'a:5:{i:1464644997;a:1:{s:29:"wp_session_garbage_collection";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:6:"hourly";s:4:"args";a:0:{}s:8:"interval";i:3600;}}}i:1464646677;a:3:{s:16:"wp_version_check";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:17:"wp_update_plugins";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}s:16:"wp_update_themes";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:10:"twicedaily";s:4:"args";a:0:{}s:8:"interval";i:43200;}}}i:1464646700;a:1:{s:19:"wp_scheduled_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}i:1464649704;a:1:{s:30:"wp_scheduled_auto_draft_delete";a:1:{s:32:"40cd750bba9870f18aada2478b24840a";a:3:{s:8:"schedule";s:5:"daily";s:4:"args";a:0:{}s:8:"interval";i:86400;}}}s:7:"version";i:2;}', 'yes'),
(138, 'theme_mods_twentysixteen', 'a:1:{s:16:"sidebars_widgets";a:2:{s:4:"time";i:1456265902;s:4:"data";a:2:{s:19:"wp_inactive_widgets";a:0:{}s:9:"sidebar-1";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}}}}', 'yes'),
(139, 'current_theme', 'FoundationPress', 'yes'),
(140, 'theme_mods_Webdesign', 'a:3:{i:0;b:0;s:18:"nav_menu_locations";a:2:{s:9:"top-bar-r";i:2;s:10:"mobile-nav";i:2;}s:16:"sidebars_widgets";a:2:{s:4:"time";i:1464545725;s:4:"data";a:3:{s:19:"wp_inactive_widgets";a:0:{}s:15:"sidebar-widgets";a:6:{i:0;s:8:"search-2";i:1;s:14:"recent-posts-2";i:2;s:17:"recent-comments-2";i:3;s:10:"archives-2";i:4;s:12:"categories-2";i:5;s:6:"meta-2";}s:14:"footer-widgets";N;}}}', 'yes'),
(141, 'theme_switched', '', 'yes'),
(143, 'nav_menu_options', 'a:2:{i:0;b:0;s:8:"auto_add";a:0:{}}', 'yes'),
(145, 'recently_activated', 'a:1:{s:19:"jetpack/jetpack.php";i:1464546997;}', 'yes'),
(146, 'wpseo', 'a:21:{s:14:"blocking_files";a:0:{}s:26:"ignore_blog_public_warning";b:0;s:31:"ignore_meta_description_warning";b:0;s:20:"ignore_page_comments";b:0;s:16:"ignore_permalink";b:0;s:15:"ms_defaults_set";b:0;s:23:"theme_description_found";s:0:"";s:21:"theme_has_description";b:0;s:7:"version";s:5:"3.2.5";s:11:"alexaverify";s:0:"";s:12:"company_logo";s:0:"";s:12:"company_name";s:0:"";s:17:"company_or_person";s:0:"";s:20:"disableadvanced_meta";b:1;s:19:"onpage_indexability";b:1;s:12:"googleverify";s:0:"";s:8:"msverify";s:0:"";s:11:"person_name";s:0:"";s:12:"website_name";s:0:"";s:22:"alternate_website_name";s:0:"";s:12:"yandexverify";s:0:"";}', 'yes'),
(147, 'wpseo_permalinks', 'a:13:{s:15:"cleanpermalinks";b:0;s:24:"cleanpermalink-extravars";s:0:"";s:29:"cleanpermalink-googlecampaign";b:0;s:31:"cleanpermalink-googlesitesearch";b:0;s:15:"cleanreplytocom";b:0;s:10:"cleanslugs";b:1;s:14:"hide-feedlinks";b:0;s:12:"hide-rsdlink";b:0;s:14:"hide-shortlink";b:0;s:16:"hide-wlwmanifest";b:0;s:18:"redirectattachment";b:0;s:17:"stripcategorybase";b:0;s:13:"trailingslash";b:0;}', 'yes'),
(148, 'wpseo_titles', 'a:54:{s:10:"title_test";i:0;s:17:"forcerewritetitle";b:0;s:9:"separator";s:7:"sc-dash";s:5:"noodp";b:0;s:6:"noydir";b:0;s:15:"usemetakeywords";b:0;s:16:"title-home-wpseo";s:42:"%%sitename%% %%page%% %%sep%% %%sitedesc%%";s:18:"title-author-wpseo";s:41:"%%name%%, Auteur à %%sitename%% %%page%%";s:19:"title-archive-wpseo";s:38:"%%date%% %%page%% %%sep%% %%sitename%%";s:18:"title-search-wpseo";s:65:"Vous avez cherché %%searchphrase%% %%page%% %%sep%% %%sitename%%";s:15:"title-404-wpseo";s:44:"La page est introuvable %%sep%% %%sitename%%";s:19:"metadesc-home-wpseo";s:0:"";s:21:"metadesc-author-wpseo";s:0:"";s:22:"metadesc-archive-wpseo";s:0:"";s:18:"metakey-home-wpseo";s:0:"";s:20:"metakey-author-wpseo";s:0:"";s:22:"noindex-subpages-wpseo";b:0;s:20:"noindex-author-wpseo";b:0;s:21:"noindex-archive-wpseo";b:1;s:14:"disable-author";b:0;s:12:"disable-date";b:0;s:10:"title-post";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-post";s:0:"";s:12:"metakey-post";s:0:"";s:12:"noindex-post";b:0;s:13:"showdate-post";b:0;s:16:"hideeditbox-post";b:0;s:10:"title-page";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:13:"metadesc-page";s:0:"";s:12:"metakey-page";s:0:"";s:12:"noindex-page";b:0;s:13:"showdate-page";b:0;s:16:"hideeditbox-page";b:0;s:16:"title-attachment";s:39:"%%title%% %%page%% %%sep%% %%sitename%%";s:19:"metadesc-attachment";s:0:"";s:18:"metakey-attachment";s:0:"";s:18:"noindex-attachment";b:0;s:19:"showdate-attachment";b:0;s:22:"hideeditbox-attachment";b:0;s:18:"title-tax-category";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-category";s:0:"";s:20:"metakey-tax-category";s:0:"";s:24:"hideeditbox-tax-category";b:0;s:20:"noindex-tax-category";b:0;s:18:"title-tax-post_tag";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:21:"metadesc-tax-post_tag";s:0:"";s:20:"metakey-tax-post_tag";s:0:"";s:24:"hideeditbox-tax-post_tag";b:0;s:20:"noindex-tax-post_tag";b:0;s:21:"title-tax-post_format";s:53:"%%term_title%% Archives %%page%% %%sep%% %%sitename%%";s:24:"metadesc-tax-post_format";s:0:"";s:23:"metakey-tax-post_format";s:0:"";s:27:"hideeditbox-tax-post_format";b:0;s:23:"noindex-tax-post_format";b:1;}', 'yes'),
(149, 'wpseo_social', 'a:21:{s:9:"fb_admins";a:0:{}s:12:"fbconnectkey";s:32:"0d16629e828ecc14952e6113f3f44a1b";s:13:"facebook_site";s:0:"";s:13:"instagram_url";s:0:"";s:12:"linkedin_url";s:0:"";s:11:"myspace_url";s:0:"";s:16:"og_default_image";s:0:"";s:18:"og_frontpage_title";s:0:"";s:17:"og_frontpage_desc";s:0:"";s:18:"og_frontpage_image";s:0:"";s:9:"opengraph";b:1;s:10:"googleplus";b:0;s:13:"pinterest_url";s:0:"";s:15:"pinterestverify";s:0:"";s:14:"plus-publisher";s:0:"";s:7:"twitter";b:1;s:12:"twitter_site";s:0:"";s:17:"twitter_card_type";s:7:"summary";s:11:"youtube_url";s:0:"";s:15:"google_plus_url";s:0:"";s:10:"fbadminapp";s:0:"";}', 'yes'),
(150, 'wpseo_rss', 'a:2:{s:9:"rssbefore";s:0:"";s:8:"rssafter";s:64:"Cet article %%POSTLINK%% est apparu en premier sur %%BLOGLINK%%.";}', 'yes'),
(151, 'wpseo_internallinks', 'a:10:{s:20:"breadcrumbs-404crumb";s:28:"Erreur 404: Page introuvable";s:23:"breadcrumbs-blog-remove";b:0;s:20:"breadcrumbs-boldlast";b:0;s:25:"breadcrumbs-archiveprefix";s:13:"Archives pour";s:18:"breadcrumbs-enable";b:0;s:16:"breadcrumbs-home";s:7:"Accueil";s:18:"breadcrumbs-prefix";s:0:"";s:24:"breadcrumbs-searchprefix";s:18:"Vous avez cherché";s:15:"breadcrumbs-sep";s:7:"&raquo;";s:23:"post_types-post-maintax";i:0;}', 'yes'),
(152, 'wpseo_xml', 'a:16:{s:22:"disable_author_sitemap";b:1;s:22:"disable_author_noposts";b:1;s:16:"enablexmlsitemap";b:1;s:16:"entries-per-page";i:1000;s:14:"excluded-posts";s:0:"";s:38:"user_role-administrator-not_in_sitemap";b:0;s:31:"user_role-editor-not_in_sitemap";b:0;s:31:"user_role-author-not_in_sitemap";b:0;s:36:"user_role-contributor-not_in_sitemap";b:0;s:35:"user_role-subscriber-not_in_sitemap";b:0;s:30:"post_types-post-not_in_sitemap";b:0;s:30:"post_types-page-not_in_sitemap";b:0;s:36:"post_types-attachment-not_in_sitemap";b:1;s:34:"taxonomies-category-not_in_sitemap";b:0;s:34:"taxonomies-post_tag-not_in_sitemap";b:0;s:37:"taxonomies-post_format-not_in_sitemap";b:0;}', 'yes'),
(154, 'jetpack_options', 'a:2:{s:7:"version";s:16:"3.9.1:1456268090";s:11:"old_version";s:16:"3.9.1:1456268090";}', 'yes'),
(155, 'jetpack_activated', '1', 'yes'),
(156, 'jetpack_file_data', 'a:1:{s:5:"3.9.7";a:49:{s:32:"31e5b9ae08b62c2b0cd8a7792242298b";a:14:{s:4:"name";s:20:"Spelling and Grammar";s:11:"description";s:89:"Check your spelling, style, and grammar with the After the Deadline proofreading service.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"6";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:7:"Writing";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:115:"after the deadline, afterthedeadline, spell, spellchecker, spelling, grammar, proofreading, style, language, cliche";}s:32:"3f41b2d629265b5de8108b463abbe8e2";a:14:{s:4:"name";s:8:"Carousel";s:11:"description";s:63:"Transform standard image galleries into full-screen slideshows.";s:14:"jumpstart_desc";s:79:"Brings your photos and images to life as full-size, easily navigable galleries.";s:4:"sort";s:2:"22";s:20:"recommendation_order";s:2:"12";s:10:"introduced";s:3:"1.5";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:17:"Photos and Videos";s:7:"feature";s:9:"Jumpstart";s:25:"additional_search_queries";s:80:"gallery, carousel, diaporama, slideshow, images, lightbox, exif, metadata, image";}s:32:"c6ebb418dde302de09600a6025370583";a:14:{s:4:"name";s:8:"Comments";s:11:"description";s:79:"Let readers comment with WordPress.com, Twitter, Facebook, or Google+ accounts.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"20";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.4";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:6:"Social";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:53:"comments, comment, facebook, twitter, google+, social";}s:32:"836f9485669e1bbb02920cb474730df0";a:14:{s:4:"name";s:12:"Contact Form";s:11:"description";s:44:"Insert a contact form anywhere on your site.";s:14:"jumpstart_desc";s:111:"Adds a button to your post and page editors, allowing you to build simple forms to help visitors stay in touch.";s:4:"sort";s:2:"15";s:20:"recommendation_order";s:2:"14";s:10:"introduced";s:3:"1.3";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:5:"Other";s:7:"feature";s:9:"Jumpstart";s:25:"additional_search_queries";s:44:"contact, form, grunion, feedback, submission";}s:32:"ea3970eebf8aac55fc3eca5dca0e0157";a:14:{s:4:"name";s:20:"Custom Content Types";s:11:"description";s:92:"Organize and display different types of content on your site, separate from posts and pages.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"34";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"3.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:7:"Writing";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:72:"cpt, custom post types, portfolio, portfolios, testimonial, testimonials";}s:32:"d2bb05ccad3d8789df40ca3abb97336c";a:14:{s:4:"name";s:10:"Custom CSS";s:11:"description";s:57:"Customize your site’s CSS without modifying your theme.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"2";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.7";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:10:"Appearance";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:108:"css, customize, custom, style, editor, less, sass, preprocessor, font, mobile, appearance, theme, stylesheet";}s:32:"a2064eec5b9c7e0d816af71dee7a715f";a:14:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:0:"";}s:32:"53a4ec755022ef3953699734c343da02";a:14:{s:4:"name";s:21:"Enhanced Distribution";s:11:"description";s:27:"Increase reach and traffic.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"5";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.2";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:6:"Public";s:11:"module_tags";s:7:"Writing";s:7:"feature";s:7:"Traffic";s:25:"additional_search_queries";s:54:"google, seo, firehose, search, broadcast, broadcasting";}s:32:"72fecb67ee6704ba0a33e0225316ad06";a:14:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:0:"";}s:32:"d56e2886185a9eace719cc57d46770df";a:14:{s:4:"name";s:19:"Gravatar Hovercards";s:11:"description";s:58:"Enable pop-up business cards over commenters’ Gravatars.";s:14:"jumpstart_desc";s:131:"Let commenters link their profiles to their Gravatar accounts, making it easy for your visitors to learn more about your community.";s:4:"sort";s:2:"11";s:20:"recommendation_order";s:2:"13";s:10:"introduced";s:3:"1.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:18:"Social, Appearance";s:7:"feature";s:9:"Jumpstart";s:25:"additional_search_queries";s:20:"gravatar, hovercards";}s:32:"e391e760617bd0e0736550e34a73d7fe";a:14:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:8:"2.0.3 ??";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:0:"";}s:32:"2e345370766346c616b3c5046e817720";a:14:{s:4:"name";s:15:"Infinite Scroll";s:11:"description";s:46:"Add support for infinite scroll to your theme.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"26";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.0";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:10:"Appearance";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:33:"scroll, infinite, infinite scroll";}s:32:"bd69edbf134de5fae8fdcf2e70a45b56";a:14:{s:4:"name";s:8:"JSON API";s:11:"description";s:69:"Allow applications to securely access your content through the cloud.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"19";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.9";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:6:"Public";s:11:"module_tags";s:19:"Writing, Developers";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:50:"api, rest, develop, developers, json, klout, oauth";}s:32:"8110b7a4423aaa619dfa46b8843e10d1";a:14:{s:4:"name";s:14:"Beautiful Math";s:11:"description";s:85:"Use LaTeX markup language in posts and pages for complex equations and other geekery.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"12";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:7:"Writing";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:47:"latex, math, equation, equations, formula, code";}s:32:"fd7e85d3b4887fa6b6f997d6592c1f33";a:14:{s:4:"name";s:5:"Likes";s:11:"description";s:70:"Give visitors an easy way to show their appreciation for your content.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"23";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.2";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:6:"Social";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:26:"like, likes, wordpress.com";}s:32:"c5dfef41fad5bcdcaae8e315e5cfc420";a:14:{s:4:"name";s:6:"Manage";s:11:"description";s:76:"Manage all your sites from a centralized place, https://wordpress.com/sites.";s:14:"jumpstart_desc";s:151:"Helps you remotely manage plugins, turn on automated updates, and more from <a href="https://wordpress.com/plugins/" target="_blank">wordpress.com</a>.";s:4:"sort";s:1:"1";s:20:"recommendation_order";s:1:"3";s:10:"introduced";s:3:"3.4";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:35:"Centralized Management, Recommended";s:7:"feature";s:22:"Recommended, Jumpstart";s:25:"additional_search_queries";s:26:"manage, management, remote";}s:32:"fd6dc399b92bce76013427e3107c314f";a:14:{s:4:"name";s:8:"Markdown";s:11:"description";s:51:"Write posts or pages in plain-text Markdown syntax.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"31";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.8";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:7:"Writing";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:12:"md, markdown";}s:32:"c49a35b6482b0426cb07ad28ecf5d7df";a:14:{s:4:"name";s:12:"Mobile Theme";s:11:"description";s:64:"Optimize your site with a mobile-friendly theme for smartphones.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"21";s:20:"recommendation_order";s:2:"11";s:10:"introduced";s:3:"1.8";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:31:"Appearance, Mobile, Recommended";s:7:"feature";s:11:"Recommended";s:25:"additional_search_queries";s:24:"mobile, theme, minileven";}s:32:"b42e38f6fafd2e4104ebe5bf39b4be47";a:14:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:0:"";}s:32:"771cfeeba0d3d23ec344d5e781fb0ae2";a:14:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:0:"";}s:32:"54f0661d27c814fc8bde39580181d939";a:14:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:0:"";}s:32:"46c4c413b5c72bbd3c3dbd14ff8f8adc";a:14:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:0:"";}s:32:"9ea52fa25783e5ceeb6bfaed3268e64e";a:14:{s:4:"name";s:7:"Monitor";s:11:"description";s:25:"Reports on site downtime.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"28";s:20:"recommendation_order";s:2:"10";s:10:"introduced";s:3:"2.6";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:11:"Recommended";s:7:"feature";s:33:"Recommended, Performance-Security";s:25:"additional_search_queries";s:37:"monitor, uptime, downtime, monitoring";}s:32:"cfcaafd0fcad087899d715e0b877474d";a:14:{s:4:"name";s:13:"Notifications";s:11:"description";s:84:"Receive notification of site activity via the admin toolbar and your Mobile devices.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"13";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.9";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:5:"Other";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:62:"notification, notifications, toolbar, adminbar, push, comments";}s:32:"0d18bfa69bec61550c1d813ce64149b0";a:14:{s:4:"name";s:10:"Omnisearch";s:11:"description";s:66:"Search your entire database from a single field in your Dashboard.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"16";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.3";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:10:"Developers";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:6:"search";}s:32:"3f0a11e23118f0788d424b646a6d465f";a:14:{s:4:"name";s:6:"Photon";s:11:"description";s:27:"Speed up images and photos.";s:14:"jumpstart_desc";s:141:"Mirrors and serves your images from our free and fast image CDN, improving your site’s performance with no additional load on your servers.";s:4:"sort";s:2:"25";s:20:"recommendation_order";s:1:"1";s:10:"introduced";s:3:"2.0";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:42:"Photos and Videos, Appearance, Recommended";s:7:"feature";s:44:"Recommended, Jumpstart, Performance-Security";s:25:"additional_search_queries";s:38:"photon, image, cdn, performance, speed";}s:32:"e37cfbcb72323fb1fe8255a2edb4d738";a:14:{s:4:"name";s:13:"Post by Email";s:11:"description";s:58:"Publish posts by email, using any device and email client.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"14";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.0";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:7:"Writing";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:20:"post by email, email";}s:32:"728290d131a480bfe7b9e405d7cd925f";a:14:{s:4:"name";s:7:"Protect";s:11:"description";s:28:"Prevent brute force attacks.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"1";s:20:"recommendation_order";s:1:"4";s:10:"introduced";s:3:"3.4";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:11:"Recommended";s:7:"feature";s:33:"Recommended, Performance-Security";s:25:"additional_search_queries";s:65:"security, secure, protection, botnet, brute force, protect, login";}s:32:"f9ce784babbbf4dcca99b8cd2ceb420c";a:14:{s:4:"name";s:9:"Publicize";s:11:"description";s:30:"Automatically promote content.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"10";s:20:"recommendation_order";s:1:"7";s:10:"introduced";s:3:"2.0";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:19:"Social, Recommended";s:7:"feature";s:20:"Recommended, Traffic";s:25:"additional_search_queries";s:107:"facebook, twitter, google+, googleplus, google, path, tumblr, linkedin, social, tweet, connections, sharing";}s:32:"052c03877dd3d296a71531cb07ad939a";a:14:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:0:"";}s:32:"52edecb2a75222e75b2dce4356a4efce";a:14:{s:4:"name";s:13:"Related Posts";s:11:"description";s:24:"Display similar content.";s:14:"jumpstart_desc";s:113:"Keep visitors engaged on your blog by highlighting relevant and new content at the bottom of each published post.";s:4:"sort";s:2:"29";s:20:"recommendation_order";s:1:"9";s:10:"introduced";s:3:"2.9";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:11:"Recommended";s:7:"feature";s:31:"Recommended, Jumpstart, Traffic";s:25:"additional_search_queries";s:22:"related, related posts";}s:32:"8b059cb50a66b717f1ec842e736b858c";a:14:{s:4:"name";s:7:"Sharing";s:11:"description";s:32:"Visitors can share your content.";s:14:"jumpstart_desc";s:116:"Twitter, Facebook and Google+ buttons at the bottom of each post, making it easy for visitors to share your content.";s:4:"sort";s:1:"7";s:20:"recommendation_order";s:1:"6";s:10:"introduced";s:3:"1.1";s:7:"changed";s:3:"1.2";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:19:"Social, Recommended";s:7:"feature";s:31:"Recommended, Jumpstart, Traffic";s:25:"additional_search_queries";s:141:"share, sharing, sharedaddy, buttons, icons, email, facebook, twitter, google+, linkedin, pinterest, pocket, press this, print, reddit, tumblr";}s:32:"a6d2394329871857401255533a9873f7";a:14:{s:4:"name";s:16:"Shortcode Embeds";s:11:"description";s:77:"Embed content from YouTube, Vimeo, SlideShare, and more, no coding necessary.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"3";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.1";s:7:"changed";s:3:"1.2";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:46:"Photos and Videos, Social, Writing, Appearance";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:251:"shortcodes, shortcode, embeds, media, bandcamp, blip.tv, dailymotion, digg, facebook, flickr, google calendars, google maps, google+, polldaddy, recipe, recipes, scribd, slideshare, slideshow, slideshows, soundcloud, ted, twitter, vimeo, vine, youtube";}s:32:"21496e2897ea5f81605e2f2ac3beb921";a:14:{s:4:"name";s:16:"WP.me Shortlinks";s:11:"description";s:56:"Enable WP.me-powered shortlinks for all posts and pages.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"8";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:6:"Social";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:17:"shortlinks, wp.me";}s:32:"e2a54a5d7879a4162709e6ffb540dd08";a:14:{s:4:"name";s:9:"Site Icon";s:11:"description";s:29:"Add a site icon to your site.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"22";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"3.2";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:5:"Other";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:24:"favicon, icon, site icon";}s:32:"f5c537bc304f55b29c1a87e30be0cd24";a:14:{s:4:"name";s:8:"Sitemaps";s:11:"description";s:75:"Creates sitemaps to allow your site to be easily indexed by search engines.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"13";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"3.9";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:6:"Public";s:11:"module_tags";s:20:"Recommended, Traffic";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:39:"sitemap, traffic, search, site map, seo";}s:32:"59a23643437358a9b557f1d1e20ab040";a:14:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:0:"";}s:32:"6a90f97c3194cfca5671728eaaeaf15e";a:14:{s:4:"name";s:14:"Single Sign On";s:11:"description";s:27:"Secure user authentication.";s:14:"jumpstart_desc";s:98:"Lets you log in to all your Jetpack-enabled sites with one click using your WordPress.com account.";s:4:"sort";s:2:"30";s:20:"recommendation_order";s:1:"5";s:10:"introduced";s:3:"2.6";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:10:"Developers";s:7:"feature";s:31:"Jumpstart, Performance-Security";s:25:"additional_search_queries";s:34:"sso, single sign on, login, log in";}s:32:"b65604e920392e2f7134b646760b75e8";a:14:{s:4:"name";s:10:"Site Stats";s:11:"description";s:35:"Collect traffic stats and insights.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"1";s:20:"recommendation_order";s:1:"2";s:10:"introduced";s:3:"1.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:23:"Site Stats, Recommended";s:7:"feature";s:20:"Recommended, Traffic";s:25:"additional_search_queries";s:54:"statistics, tracking, analytics, views, traffic, stats";}s:32:"23a586dd7ead00e69ec53eb32ef740e4";a:14:{s:4:"name";s:13:"Subscriptions";s:11:"description";s:88:"Allow users to subscribe to your posts and comments and receive notifications via email.";s:14:"jumpstart_desc";s:126:"Give visitors two easy subscription options — while commenting, or via a separate email subscription widget you can display.";s:4:"sort";s:1:"9";s:20:"recommendation_order";s:1:"8";s:10:"introduced";s:3:"1.2";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:6:"Social";s:7:"feature";s:9:"Jumpstart";s:25:"additional_search_queries";s:74:"subscriptions, subscription, email, follow, followers, subscribers, signup";}s:32:"1d978b8d84d2f378fe1a702a67633b6d";a:14:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:0:"";}s:32:"b3b983461d7f3d27322a3551ed8a9405";a:14:{s:4:"name";s:15:"Tiled Galleries";s:11:"description";s:73:"Display your image galleries in a variety of sleek, graphic arrangements.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"24";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.1";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:2:"No";s:11:"module_tags";s:17:"Photos and Videos";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:43:"gallery, tiles, tiled, grid, mosaic, images";}s:32:"d924e5b05722b0e104448543598f54c0";a:14:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:0:"";}s:32:"36741583b10c521997e563ad8e1e8b77";a:14:{s:4:"name";s:12:"Data Backups";s:11:"description";s:27:"Daily or real-time backups.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"32";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:5:"0:1.2";s:7:"changed";s:0:"";s:10:"deactivate";s:5:"false";s:4:"free";s:5:"false";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:0:"";s:7:"feature";s:20:"Performance-Security";s:25:"additional_search_queries";s:28:"vaultpress, backup, security";}s:32:"2b9b44f09b5459617d68dd82ee17002a";a:14:{s:4:"name";s:17:"Site Verification";s:11:"description";s:77:"Verify your site or domain with Google Search Console, Pinterest, and others.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"33";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"3.0";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:56:"webmaster, seo, google, bing, pinterest, search, console";}s:32:"5ab4c0db7c42e10e646342da0274c491";a:14:{s:4:"name";s:10:"VideoPress";s:11:"description";s:68:"Upload and embed videos right on your site. (Subscription required.)";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"27";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.5";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:5:"false";s:19:"requires_connection";s:3:"Yes";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:17:"Photos and Videos";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:25:"video, videos, videopress";}s:32:"60a1d3aa38bc0fe1039e59dd60888543";a:14:{s:4:"name";s:17:"Widget Visibility";s:11:"description";s:57:"Specify which widgets appear on which pages of your site.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:2:"17";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"2.4";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:10:"Appearance";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:54:"widget visibility, logic, conditional, widgets, widget";}s:32:"174ed3416476c2cb9ff5b0f671280b15";a:14:{s:4:"name";s:21:"Extra Sidebar Widgets";s:11:"description";s:79:"Add images, Twitter streams, your site’s RSS links, and more to your sidebar.";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:1:"4";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:3:"1.2";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:2:"No";s:13:"auto_activate";s:3:"Yes";s:11:"module_tags";s:18:"Social, Appearance";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:65:"widget, widgets, facebook, gallery, twitter, gravatar, image, rss";}s:32:"28b931a1db19bd24869bd54b14e733d5";a:14:{s:4:"name";s:0:"";s:11:"description";s:0:"";s:14:"jumpstart_desc";s:0:"";s:4:"sort";s:0:"";s:20:"recommendation_order";s:0:"";s:10:"introduced";s:0:"";s:7:"changed";s:0:"";s:10:"deactivate";s:0:"";s:4:"free";s:0:"";s:19:"requires_connection";s:0:"";s:13:"auto_activate";s:0:"";s:11:"module_tags";s:0:"";s:7:"feature";s:0:"";s:25:"additional_search_queries";s:0:"";}}}', 'yes'),
(157, 'jetpack_available_modules', 'a:1:{s:5:"3.9.7";a:37:{s:18:"after-the-deadline";s:3:"1.1";s:8:"carousel";s:3:"1.5";s:8:"comments";s:3:"1.4";s:12:"contact-form";s:3:"1.3";s:20:"custom-content-types";s:3:"3.1";s:10:"custom-css";s:3:"1.7";s:21:"enhanced-distribution";s:3:"1.2";s:19:"gravatar-hovercards";s:3:"1.1";s:15:"infinite-scroll";s:3:"2.0";s:8:"json-api";s:3:"1.9";s:5:"latex";s:3:"1.1";s:5:"likes";s:3:"2.2";s:6:"manage";s:3:"3.4";s:8:"markdown";s:3:"2.8";s:9:"minileven";s:3:"1.8";s:7:"monitor";s:3:"2.6";s:5:"notes";s:3:"1.9";s:10:"omnisearch";s:3:"2.3";s:6:"photon";s:3:"2.0";s:13:"post-by-email";s:3:"2.0";s:7:"protect";s:3:"3.4";s:9:"publicize";s:3:"2.0";s:13:"related-posts";s:3:"2.9";s:10:"sharedaddy";s:3:"1.1";s:10:"shortcodes";s:3:"1.1";s:10:"shortlinks";s:3:"1.1";s:9:"site-icon";s:3:"3.2";s:8:"sitemaps";s:3:"3.9";s:3:"sso";s:3:"2.6";s:5:"stats";s:3:"1.1";s:13:"subscriptions";s:3:"1.2";s:13:"tiled-gallery";s:3:"2.1";s:10:"vaultpress";s:5:"0:1.2";s:18:"verification-tools";s:3:"3.0";s:10:"videopress";s:3:"2.5";s:17:"widget-visibility";s:3:"2.4";s:7:"widgets";s:3:"1.2";}}', 'yes'),
(161, 'jetpack_security_report', 'a:0:{}', 'yes'),
(196, 'astuces_children', 'a:0:{}', 'yes'),
(326, 'theme_mods_themewebdesign', 'a:2:{i:0;b:0;s:18:"nav_menu_locations";a:3:{s:9:"top-bar-r";i:2;s:10:"mobile-nav";i:2;s:11:"header-menu";i:5;}}', 'yes'),
(329, 'rewrite_rules', 'a:103:{s:19:"sitemap_index\\.xml$";s:19:"index.php?sitemap=1";s:31:"([^/]+?)-sitemap([0-9]+)?\\.xml$";s:51:"index.php?sitemap=$matches[1]&sitemap_n=$matches[2]";s:24:"([a-z]+)?-?sitemap\\.xsl$";s:25:"index.php?xsl=$matches[1]";s:10:"astuces/?$";s:27:"index.php?post_type=astuces";s:40:"astuces/feed/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=astuces&feed=$matches[1]";s:35:"astuces/(feed|rdf|rss|rss2|atom)/?$";s:44:"index.php?post_type=astuces&feed=$matches[1]";s:27:"astuces/page/([0-9]{1,})/?$";s:45:"index.php?post_type=astuces&paged=$matches[1]";s:11:"^wp-json/?$";s:22:"index.php?rest_route=/";s:14:"^wp-json/(.*)?";s:33:"index.php?rest_route=/$matches[1]";s:47:"category/(.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:42:"category/(.+?)/(feed|rdf|rss|rss2|atom)/?$";s:52:"index.php?category_name=$matches[1]&feed=$matches[2]";s:23:"category/(.+?)/embed/?$";s:46:"index.php?category_name=$matches[1]&embed=true";s:35:"category/(.+?)/page/?([0-9]{1,})/?$";s:53:"index.php?category_name=$matches[1]&paged=$matches[2]";s:17:"category/(.+?)/?$";s:35:"index.php?category_name=$matches[1]";s:44:"tag/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:39:"tag/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?tag=$matches[1]&feed=$matches[2]";s:20:"tag/([^/]+)/embed/?$";s:36:"index.php?tag=$matches[1]&embed=true";s:32:"tag/([^/]+)/page/?([0-9]{1,})/?$";s:43:"index.php?tag=$matches[1]&paged=$matches[2]";s:14:"tag/([^/]+)/?$";s:25:"index.php?tag=$matches[1]";s:45:"type/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:40:"type/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?post_format=$matches[1]&feed=$matches[2]";s:21:"type/([^/]+)/embed/?$";s:44:"index.php?post_format=$matches[1]&embed=true";s:33:"type/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?post_format=$matches[1]&paged=$matches[2]";s:15:"type/([^/]+)/?$";s:33:"index.php?post_format=$matches[1]";s:35:"astuces/[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:45:"astuces/[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:65:"astuces/[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"astuces/[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:60:"astuces/[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:41:"astuces/[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:24:"astuces/([^/]+)/embed/?$";s:40:"index.php?astuces=$matches[1]&embed=true";s:28:"astuces/([^/]+)/trackback/?$";s:34:"index.php?astuces=$matches[1]&tb=1";s:48:"astuces/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?astuces=$matches[1]&feed=$matches[2]";s:43:"astuces/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:46:"index.php?astuces=$matches[1]&feed=$matches[2]";s:36:"astuces/([^/]+)/page/?([0-9]{1,})/?$";s:47:"index.php?astuces=$matches[1]&paged=$matches[2]";s:32:"astuces/([^/]+)(?:/([0-9]+))?/?$";s:46:"index.php?astuces=$matches[1]&page=$matches[2]";s:48:".*wp-(atom|rdf|rss|rss2|feed|commentsrss2)\\.php$";s:18:"index.php?feed=old";s:20:".*wp-app\\.php(/.*)?$";s:19:"index.php?error=403";s:18:".*wp-register.php$";s:23:"index.php?register=true";s:32:"feed/(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:27:"(feed|rdf|rss|rss2|atom)/?$";s:27:"index.php?&feed=$matches[1]";s:8:"embed/?$";s:21:"index.php?&embed=true";s:20:"page/?([0-9]{1,})/?$";s:28:"index.php?&paged=$matches[1]";s:41:"comments/feed/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:36:"comments/(feed|rdf|rss|rss2|atom)/?$";s:42:"index.php?&feed=$matches[1]&withcomments=1";s:17:"comments/embed/?$";s:21:"index.php?&embed=true";s:44:"search/(.+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:39:"search/(.+)/(feed|rdf|rss|rss2|atom)/?$";s:40:"index.php?s=$matches[1]&feed=$matches[2]";s:20:"search/(.+)/embed/?$";s:34:"index.php?s=$matches[1]&embed=true";s:32:"search/(.+)/page/?([0-9]{1,})/?$";s:41:"index.php?s=$matches[1]&paged=$matches[2]";s:14:"search/(.+)/?$";s:23:"index.php?s=$matches[1]";s:47:"author/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:42:"author/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:50:"index.php?author_name=$matches[1]&feed=$matches[2]";s:23:"author/([^/]+)/embed/?$";s:44:"index.php?author_name=$matches[1]&embed=true";s:35:"author/([^/]+)/page/?([0-9]{1,})/?$";s:51:"index.php?author_name=$matches[1]&paged=$matches[2]";s:17:"author/([^/]+)/?$";s:33:"index.php?author_name=$matches[1]";s:69:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:64:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:80:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&feed=$matches[4]";s:45:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/embed/?$";s:74:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&embed=true";s:57:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:81:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]&paged=$matches[4]";s:39:"([0-9]{4})/([0-9]{1,2})/([0-9]{1,2})/?$";s:63:"index.php?year=$matches[1]&monthnum=$matches[2]&day=$matches[3]";s:56:"([0-9]{4})/([0-9]{1,2})/feed/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:51:"([0-9]{4})/([0-9]{1,2})/(feed|rdf|rss|rss2|atom)/?$";s:64:"index.php?year=$matches[1]&monthnum=$matches[2]&feed=$matches[3]";s:32:"([0-9]{4})/([0-9]{1,2})/embed/?$";s:58:"index.php?year=$matches[1]&monthnum=$matches[2]&embed=true";s:44:"([0-9]{4})/([0-9]{1,2})/page/?([0-9]{1,})/?$";s:65:"index.php?year=$matches[1]&monthnum=$matches[2]&paged=$matches[3]";s:26:"([0-9]{4})/([0-9]{1,2})/?$";s:47:"index.php?year=$matches[1]&monthnum=$matches[2]";s:43:"([0-9]{4})/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:38:"([0-9]{4})/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?year=$matches[1]&feed=$matches[2]";s:19:"([0-9]{4})/embed/?$";s:37:"index.php?year=$matches[1]&embed=true";s:31:"([0-9]{4})/page/?([0-9]{1,})/?$";s:44:"index.php?year=$matches[1]&paged=$matches[2]";s:13:"([0-9]{4})/?$";s:26:"index.php?year=$matches[1]";s:27:".?.+?/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:".?.+?/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:".?.+?/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:".?.+?/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:".?.+?/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"(.?.+?)/embed/?$";s:41:"index.php?pagename=$matches[1]&embed=true";s:20:"(.?.+?)/trackback/?$";s:35:"index.php?pagename=$matches[1]&tb=1";s:40:"(.?.+?)/feed/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:35:"(.?.+?)/(feed|rdf|rss|rss2|atom)/?$";s:47:"index.php?pagename=$matches[1]&feed=$matches[2]";s:28:"(.?.+?)/page/?([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&paged=$matches[2]";s:35:"(.?.+?)/comment-page-([0-9]{1,})/?$";s:48:"index.php?pagename=$matches[1]&cpage=$matches[2]";s:24:"(.?.+?)(?:/([0-9]+))?/?$";s:47:"index.php?pagename=$matches[1]&page=$matches[2]";s:27:"[^/]+/attachment/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:37:"[^/]+/attachment/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:57:"[^/]+/attachment/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:52:"[^/]+/attachment/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:33:"[^/]+/attachment/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";s:16:"([^/]+)/embed/?$";s:37:"index.php?name=$matches[1]&embed=true";s:20:"([^/]+)/trackback/?$";s:31:"index.php?name=$matches[1]&tb=1";s:40:"([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:35:"([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:43:"index.php?name=$matches[1]&feed=$matches[2]";s:28:"([^/]+)/page/?([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&paged=$matches[2]";s:35:"([^/]+)/comment-page-([0-9]{1,})/?$";s:44:"index.php?name=$matches[1]&cpage=$matches[2]";s:24:"([^/]+)(?:/([0-9]+))?/?$";s:43:"index.php?name=$matches[1]&page=$matches[2]";s:16:"[^/]+/([^/]+)/?$";s:32:"index.php?attachment=$matches[1]";s:26:"[^/]+/([^/]+)/trackback/?$";s:37:"index.php?attachment=$matches[1]&tb=1";s:46:"[^/]+/([^/]+)/feed/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/(feed|rdf|rss|rss2|atom)/?$";s:49:"index.php?attachment=$matches[1]&feed=$matches[2]";s:41:"[^/]+/([^/]+)/comment-page-([0-9]{1,})/?$";s:50:"index.php?attachment=$matches[1]&cpage=$matches[2]";s:22:"[^/]+/([^/]+)/embed/?$";s:43:"index.php?attachment=$matches[1]&embed=true";}', 'yes'),
(342, 'db_upgraded', '', 'yes'),
(345, 'can_compress_scripts', '1', 'yes'),
(350, 'wpseo_sitemap_cache_validator_global', '5Piw6', 'yes'),
(355, 'jetpack_unique_connection', 'a:1:{s:12:"disconnected";i:1;}', 'yes'),
(357, 'wpseo_sitemap_1_cache_validator', '6llnd', 'yes'),
(358, 'wpseo_sitemap_astuces_cache_validator', '6EmKC', 'yes'),
(359, 'wpseo_sitemap_revision_cache_validator', '6llmV', 'yes'),
(360, 'wpseo_sitemap_nav_menu_item_cache_validator', '693mD', 'yes'),
(361, 'wpseo_sitemap_nav_menu_cache_validator', '693mG', 'yes'),
(362, 'wpseo_sitemap_11_cache_validator', '5Rcye', 'yes'),
(363, 'wpseo_sitemap_16_cache_validator', '5Rcyv', 'yes'),
(365, 'wpseo_sitemap_post_cache_validator', '6llne', 'yes'),
(366, 'wpseo_sitemap_category_cache_validator', '6llmL', 'yes'),
(371, 'asl_version', '4620', 'yes'),
(374, 'widget_ajaxsearchlitewidget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes') ;
INSERT INTO `wp_wd_options` ( `option_id`, `option_name`, `option_value`, `autoload`) VALUES
(378, 'asl_debug_data', 'a:2:{s:11:"asl_options";a:134:{s:5:"theme";s:9:"underline";s:20:"override_search_form";s:1:"0";s:14:"triggeronclick";s:1:"1";s:23:"trigger_on_facet_change";s:1:"1";s:15:"redirectonclick";s:1:"0";s:17:"redirect_click_to";s:12:"results_page";s:17:"redirect_on_enter";s:1:"0";s:17:"redirect_enter_to";s:12:"results_page";s:13:"triggerontype";s:1:"1";s:13:"searchinposts";s:1:"1";s:13:"searchinpages";s:1:"1";s:11:"customtypes";s:0:"";s:13:"searchintitle";s:1:"1";s:15:"searchincontent";s:1:"1";s:15:"searchinexcerpt";s:1:"1";s:12:"customfields";s:0:"";s:24:"override_default_results";s:1:"0";s:9:"exactonly";s:1:"0";s:13:"searchinterms";s:1:"0";s:9:"charcount";s:1:"3";s:10:"maxresults";s:2:"10";s:10:"itemscount";s:1:"4";s:16:"resultitemheight";s:4:"70px";s:15:"orderby_primary";s:14:"relevance DESC";s:17:"orderby_secondary";s:9:"date DESC";s:11:"show_images";s:1:"1";s:18:"image_transparency";i:1;s:14:"image_bg_color";s:7:"#FFFFFF";s:11:"image_width";s:2:"70";s:12:"image_height";s:2:"70";s:19:"image_crop_location";s:1:"c";s:27:"image_crop_location_selects";a:9:{i:0;a:2:{s:6:"option";s:13:"In the center";s:5:"value";s:1:"c";}i:1;a:2:{s:6:"option";s:9:"Align top";s:5:"value";s:1:"t";}i:2;a:2:{s:6:"option";s:15:"Align top right";s:5:"value";s:2:"tr";}i:3;a:2:{s:6:"option";s:14:"Align top left";s:5:"value";s:2:"tl";}i:4;a:2:{s:6:"option";s:12:"Align bottom";s:5:"value";s:1:"b";}i:5;a:2:{s:6:"option";s:18:"Align bottom right";s:5:"value";s:2:"br";}i:6;a:2:{s:6:"option";s:17:"Align bottom left";s:5:"value";s:2:"bl";}i:7;a:2:{s:6:"option";s:10:"Align left";s:5:"value";s:1:"l";}i:8;a:2:{s:6:"option";s:11:"Align right";s:5:"value";s:1:"r";}}s:13:"image_sources";a:7:{i:0;a:2:{s:6:"option";s:14:"Featured image";s:5:"value";s:8:"featured";}i:1;a:2:{s:6:"option";s:12:"Post Content";s:5:"value";s:7:"content";}i:2;a:2:{s:6:"option";s:12:"Post Excerpt";s:5:"value";s:7:"excerpt";}i:3;a:2:{s:6:"option";s:12:"Custom field";s:5:"value";s:6:"custom";}i:4;a:2:{s:6:"option";s:15:"Page Screenshot";s:5:"value";s:10:"screenshot";}i:5;a:2:{s:6:"option";s:13:"Default image";s:5:"value";s:7:"default";}i:6;a:2:{s:6:"option";s:8:"Disabled";s:5:"value";s:8:"disabled";}}s:13:"image_source1";s:8:"featured";s:13:"image_source2";s:7:"content";s:13:"image_source3";s:7:"excerpt";s:13:"image_source4";s:6:"custom";s:13:"image_source5";s:7:"default";s:13:"image_default";s:87:"http://localhost:8888/blogwebdesign/wp-content/plugins/ajax-search-lite/img/default.jpg";s:18:"image_custom_field";s:0:"";s:12:"use_timthumb";i:1;s:29:"show_frontend_search_settings";s:1:"0";s:16:"showexactmatches";s:1:"1";s:17:"showsearchinposts";s:1:"0";s:17:"showsearchinpages";s:1:"0";s:17:"showsearchintitle";s:1:"1";s:19:"showsearchincontent";s:1:"0";s:15:"showcustomtypes";s:0:"";s:20:"showsearchincomments";i:1;s:19:"showsearchinexcerpt";i:1;s:19:"showsearchinbpusers";i:0;s:20:"showsearchinbpgroups";i:0;s:20:"showsearchinbpforums";i:0;s:16:"exactmatchestext";s:19:"Mot exact seulement";s:17:"searchinpoststext";s:15:"Search in posts";s:17:"searchinpagestext";s:15:"Search in pages";s:17:"searchintitletext";s:24:"Rechercher dans le titre";s:19:"searchincontenttext";s:17:"Search in content";s:20:"searchincommentstext";s:18:"Search in comments";s:19:"searchinexcerpttext";s:17:"Search in excerpt";s:19:"searchinbpuserstext";s:15:"Search in users";s:20:"searchinbpgroupstext";s:16:"Search in groups";s:20:"searchinbpforumstext";s:16:"Search in forums";s:22:"showsearchincategories";s:1:"1";s:17:"showuncategorised";s:1:"1";s:20:"exsearchincategories";s:0:"";s:26:"exsearchincategoriesheight";i:200;s:22:"showsearchintaxonomies";i:1;s:9:"showterms";s:0:"";s:23:"showseparatefilterboxes";i:1;s:24:"exsearchintaxonomiestext";s:9:"Filter by";s:24:"exsearchincategoriestext";s:20:"Filter by Categories";s:9:"box_width";s:4:"100%";s:10:"box_margin";s:22:"||0px||0px||0px||0px||";s:15:"resultstype_def";a:4:{i:0;a:2:{s:6:"option";s:16:"Vertical Results";s:5:"value";s:8:"vertical";}i:1;a:2:{s:6:"option";s:18:"Horizontal Results";s:5:"value";s:10:"horizontal";}i:2;a:2:{s:6:"option";s:16:"Isotopic Results";s:5:"value";s:8:"isotopic";}i:3;a:2:{s:6:"option";s:22:"Polaroid style Results";s:5:"value";s:8:"polaroid";}}s:11:"resultstype";s:8:"vertical";s:19:"resultsposition_def";a:2:{i:0;a:2:{s:6:"option";s:20:"Hover - over content";s:5:"value";s:5:"hover";}i:1;a:2:{s:6:"option";s:22:"Block - pushes content";s:5:"value";s:5:"block";}}s:15:"resultsposition";s:5:"hover";s:16:"resultsmargintop";s:4:"12px";s:17:"defaultsearchtext";s:24:"Faire une recherche ....";s:15:"showmoreresults";s:1:"0";s:19:"showmoreresultstext";s:22:"Plus de résultats ...";s:12:"showmorefont";s:151:"font-weight:normal;font-family:--g--Open Sans;color:rgba(5, 94, 148, 1);font-size:12px;line-height:15px;text-shadow:0px 0px 0px rgba(255, 255, 255, 0);";s:17:"scroll_to_results";s:1:"0";s:19:"resultareaclickable";s:1:"1";s:23:"close_on_document_click";s:1:"1";s:15:"show_close_icon";s:1:"1";s:10:"showauthor";s:1:"0";s:8:"showdate";s:1:"0";s:15:"showdescription";s:1:"1";s:17:"descriptionlength";s:3:"100";s:19:"description_context";s:1:"0";s:13:"noresultstext";s:11:"No results!";s:14:"didyoumeantext";s:13:"Did you mean:";s:12:"kw_highlight";s:1:"0";s:24:"kw_highlight_whole_words";s:1:"1";s:15:"highlight_color";s:20:"rgba(217, 49, 43, 1)";s:18:"highlight_bg_color";s:22:"rgba(238, 238, 238, 1)";s:12:"autocomplete";s:1:"1";s:14:"kw_suggestions";s:1:"1";s:9:"kw_length";s:2:"60";s:8:"kw_count";s:2:"10";s:14:"kw_google_lang";s:2:"en";s:13:"kw_exceptions";s:0:"";s:12:"shortcode_op";s:6:"remove";s:16:"striptagsexclude";s:0:"";s:12:"runshortcode";i:1;s:14:"stripshortcode";i:0;s:19:"pageswithcategories";i:0;s:14:"titlefield_def";a:2:{i:0;a:2:{s:6:"option";s:10:"Post Title";s:5:"value";i:0;}i:1;a:2:{s:6:"option";s:12:"Post Excerpt";s:5:"value";i:1;}}s:10:"titlefield";s:1:"0";s:20:"descriptionfield_def";a:3:{i:0;a:2:{s:6:"option";s:16:"Post Description";s:5:"value";i:0;}i:1;a:2:{s:6:"option";s:12:"Post Excerpt";s:5:"value";i:1;}i:2;a:2:{s:6:"option";s:10:"Post Title";s:5:"value";i:2;}}s:16:"descriptionfield";s:1:"0";s:17:"excludecategories";s:0:"";s:12:"excludeposts";s:0:"";s:16:"exclude_term_ids";s:0:"";s:18:"wpml_compatibility";s:1:"1";s:21:"classname-customtypes";s:23:"wpdreamsCustomPostTypes";s:22:"classname-customfields";s:20:"wpdreamsCustomFields";s:10:"asl_submit";s:1:"1";s:10:"submit_asl";s:13:"Save options!";s:25:"classname-showcustomtypes";s:31:"wpdreamsCustomPostTypesEditable";s:30:"classname-exsearchincategories";s:18:"wpdreamsCategories";s:7:"topleft";s:3:"0px";s:11:"bottomright";s:3:"0px";s:8:"topright";s:3:"0px";s:10:"bottomleft";s:3:"0px";s:27:"classname-excludecategories";s:18:"wpdreamsCategories";s:10:"sett_tabid";s:1:"3";s:20:"selected-customtypes";N;s:21:"selected-customfields";N;s:24:"selected-showcustomtypes";N;s:29:"selected-exsearchincategories";N;s:26:"selected-excludecategories";N;}s:7:"queries";a:5:{i:0;a:4:{s:6:"phrase";s:7:"bonjour";s:7:"options";a:16:{s:15:"qtranslate_lang";s:1:"0";s:11:"set_intitle";b:1;s:13:"set_incontent";b:1;s:13:"set_inexcerpt";b:1;s:11:"set_inposts";b:1;s:11:"set_inpages";b:1;s:11:"categoryset";a:1:{i:0;s:1:"1";}s:13:"set_exactonly";b:0;s:14:"set_incomments";b:0;s:13:"searchinterms";b:0;s:13:"set_inbpusers";b:0;s:14:"set_inbpgroups";b:0;s:14:"set_inbpforums";b:0;s:10:"maxresults";s:2:"10";s:8:"do_group";b:1;s:7:"termset";a:0:{}}s:5:"query";s:1774:"\r\n    		SELECT \r\n          wp_wd_posts.post_title as title,\r\n          wp_wd_posts.ID as id,\r\n          wp_wd_posts.post_date as date,               \r\n          wp_wd_posts.post_content as content,\r\n          \'\' as excerpt,\r\n          \'pagepost\' as content_type,\r\n	        (SELECT\r\n	            wp_wd_users.display_name as author\r\n	            FROM wp_wd_users\r\n	            WHERE wp_wd_users.ID = wp_wd_posts.post_author\r\n	        ) as author,\r\n          \'\' as ttid,\r\n          wp_wd_posts.post_type as post_type,\r\n          ((case when\r\n                (wp_wd_posts.post_title LIKE \'%bonjour%\')\r\n                 then 10 else 0 end) + (case when\r\n                  (wp_wd_posts.post_title LIKE \'%bonjour%\')\r\n                   then 10 else 0 end) + (case when\r\n                    (wp_wd_posts.post_content LIKE \'%bonjour%\')\r\n                     then 8 else 0 end) + (case when\r\n                (wp_wd_posts.post_content LIKE \'%bonjour%\')\r\n                 then 8 else 0 end) + (case when\r\n                    (wp_wd_posts.post_excerpt LIKE \'%bonjour%\')\r\n                     then 7 else 0 end) + (case when\r\n                (wp_wd_posts.post_excerpt LIKE \'%bonjour%\')\r\n                 then 7 else 0 end)) as relevance\r\n    		FROM wp_wd_posts\r\n        \r\n        \r\n    	WHERE\r\n                (wp_wd_posts.post_type IN (\'post\',\'page\') )\r\n            AND ( wp_wd_posts.post_status = \'publish\')\r\n            AND (1)\r\n            AND (( wp_wd_posts.post_title LIKE \'%bonjour%\' ) OR ( wp_wd_posts.post_content LIKE \'%bonjour%\' ) OR ( wp_wd_posts.post_excerpt LIKE \'%bonjour%\' ))\r\n            AND (wp_wd_posts.ID NOT IN (-55))\r\n            AND ( (1) )\r\n        GROUP BY\r\n          wp_wd_posts.ID\r\n        ORDER BY\r\n        	relevance DESC, date DESC, id DESC\r\n        LIMIT 10";s:7:"results";i:2;}i:1;a:4:{s:6:"phrase";s:6:"bonouo";s:7:"options";a:16:{s:15:"qtranslate_lang";s:1:"0";s:11:"set_intitle";b:1;s:13:"set_incontent";b:1;s:13:"set_inexcerpt";b:1;s:11:"set_inposts";b:1;s:11:"set_inpages";b:1;s:11:"categoryset";a:1:{i:0;s:1:"1";}s:13:"set_exactonly";b:0;s:14:"set_incomments";b:0;s:13:"searchinterms";b:0;s:13:"set_inbpusers";b:0;s:14:"set_inbpgroups";b:0;s:14:"set_inbpforums";b:0;s:10:"maxresults";s:2:"10";s:8:"do_group";b:1;s:7:"termset";a:0:{}}s:5:"query";s:1765:"\r\n    		SELECT \r\n          wp_wd_posts.post_title as title,\r\n          wp_wd_posts.ID as id,\r\n          wp_wd_posts.post_date as date,               \r\n          wp_wd_posts.post_content as content,\r\n          \'\' as excerpt,\r\n          \'pagepost\' as content_type,\r\n	        (SELECT\r\n	            wp_wd_users.display_name as author\r\n	            FROM wp_wd_users\r\n	            WHERE wp_wd_users.ID = wp_wd_posts.post_author\r\n	        ) as author,\r\n          \'\' as ttid,\r\n          wp_wd_posts.post_type as post_type,\r\n          ((case when\r\n                (wp_wd_posts.post_title LIKE \'%bonouo%\')\r\n                 then 10 else 0 end) + (case when\r\n                  (wp_wd_posts.post_title LIKE \'%bonouo%\')\r\n                   then 10 else 0 end) + (case when\r\n                    (wp_wd_posts.post_content LIKE \'%bonouo%\')\r\n                     then 8 else 0 end) + (case when\r\n                (wp_wd_posts.post_content LIKE \'%bonouo%\')\r\n                 then 8 else 0 end) + (case when\r\n                    (wp_wd_posts.post_excerpt LIKE \'%bonouo%\')\r\n                     then 7 else 0 end) + (case when\r\n                (wp_wd_posts.post_excerpt LIKE \'%bonouo%\')\r\n                 then 7 else 0 end)) as relevance\r\n    		FROM wp_wd_posts\r\n        \r\n        \r\n    	WHERE\r\n                (wp_wd_posts.post_type IN (\'post\',\'page\') )\r\n            AND ( wp_wd_posts.post_status = \'publish\')\r\n            AND (1)\r\n            AND (( wp_wd_posts.post_title LIKE \'%bonouo%\' ) OR ( wp_wd_posts.post_content LIKE \'%bonouo%\' ) OR ( wp_wd_posts.post_excerpt LIKE \'%bonouo%\' ))\r\n            AND (wp_wd_posts.ID NOT IN (-55))\r\n            AND ( (1) )\r\n        GROUP BY\r\n          wp_wd_posts.ID\r\n        ORDER BY\r\n        	relevance DESC, date DESC, id DESC\r\n        LIMIT 10";s:7:"results";i:0;}i:2;a:4:{s:6:"phrase";s:7:"bonjour";s:7:"options";a:16:{s:15:"qtranslate_lang";s:1:"0";s:11:"set_intitle";b:1;s:13:"set_incontent";b:1;s:13:"set_inexcerpt";b:1;s:11:"set_inposts";b:1;s:11:"set_inpages";b:1;s:11:"categoryset";a:1:{i:0;s:1:"1";}s:13:"set_exactonly";b:0;s:14:"set_incomments";b:0;s:13:"searchinterms";b:0;s:13:"set_inbpusers";b:0;s:14:"set_inbpgroups";b:0;s:14:"set_inbpforums";b:0;s:10:"maxresults";s:2:"10";s:8:"do_group";b:1;s:7:"termset";a:0:{}}s:5:"query";s:1774:"\r\n    		SELECT \r\n          wp_wd_posts.post_title as title,\r\n          wp_wd_posts.ID as id,\r\n          wp_wd_posts.post_date as date,               \r\n          wp_wd_posts.post_content as content,\r\n          \'\' as excerpt,\r\n          \'pagepost\' as content_type,\r\n	        (SELECT\r\n	            wp_wd_users.display_name as author\r\n	            FROM wp_wd_users\r\n	            WHERE wp_wd_users.ID = wp_wd_posts.post_author\r\n	        ) as author,\r\n          \'\' as ttid,\r\n          wp_wd_posts.post_type as post_type,\r\n          ((case when\r\n                (wp_wd_posts.post_title LIKE \'%bonjour%\')\r\n                 then 10 else 0 end) + (case when\r\n                  (wp_wd_posts.post_title LIKE \'%bonjour%\')\r\n                   then 10 else 0 end) + (case when\r\n                    (wp_wd_posts.post_content LIKE \'%bonjour%\')\r\n                     then 8 else 0 end) + (case when\r\n                (wp_wd_posts.post_content LIKE \'%bonjour%\')\r\n                 then 8 else 0 end) + (case when\r\n                    (wp_wd_posts.post_excerpt LIKE \'%bonjour%\')\r\n                     then 7 else 0 end) + (case when\r\n                (wp_wd_posts.post_excerpt LIKE \'%bonjour%\')\r\n                 then 7 else 0 end)) as relevance\r\n    		FROM wp_wd_posts\r\n        \r\n        \r\n    	WHERE\r\n                (wp_wd_posts.post_type IN (\'post\',\'page\') )\r\n            AND ( wp_wd_posts.post_status = \'publish\')\r\n            AND (1)\r\n            AND (( wp_wd_posts.post_title LIKE \'%bonjour%\' ) OR ( wp_wd_posts.post_content LIKE \'%bonjour%\' ) OR ( wp_wd_posts.post_excerpt LIKE \'%bonjour%\' ))\r\n            AND (wp_wd_posts.ID NOT IN (-55))\r\n            AND ( (1) )\r\n        GROUP BY\r\n          wp_wd_posts.ID\r\n        ORDER BY\r\n        	relevance DESC, date DESC, id DESC\r\n        LIMIT 10";s:7:"results";i:2;}i:3;a:4:{s:6:"phrase";s:3:"bon";s:7:"options";a:16:{s:15:"qtranslate_lang";s:1:"0";s:11:"set_intitle";b:1;s:13:"set_incontent";b:1;s:13:"set_inexcerpt";b:1;s:11:"set_inposts";b:1;s:11:"set_inpages";b:1;s:11:"categoryset";a:1:{i:0;s:1:"1";}s:13:"set_exactonly";b:0;s:14:"set_incomments";b:0;s:13:"searchinterms";b:0;s:13:"set_inbpusers";b:0;s:14:"set_inbpgroups";b:0;s:14:"set_inbpforums";b:0;s:10:"maxresults";s:2:"10";s:8:"do_group";b:1;s:7:"termset";a:0:{}}s:5:"query";s:1738:"\r\n    		SELECT \r\n          wp_wd_posts.post_title as title,\r\n          wp_wd_posts.ID as id,\r\n          wp_wd_posts.post_date as date,               \r\n          wp_wd_posts.post_content as content,\r\n          \'\' as excerpt,\r\n          \'pagepost\' as content_type,\r\n	        (SELECT\r\n	            wp_wd_users.display_name as author\r\n	            FROM wp_wd_users\r\n	            WHERE wp_wd_users.ID = wp_wd_posts.post_author\r\n	        ) as author,\r\n          \'\' as ttid,\r\n          wp_wd_posts.post_type as post_type,\r\n          ((case when\r\n                (wp_wd_posts.post_title LIKE \'%bon%\')\r\n                 then 10 else 0 end) + (case when\r\n                  (wp_wd_posts.post_title LIKE \'%bon%\')\r\n                   then 10 else 0 end) + (case when\r\n                    (wp_wd_posts.post_content LIKE \'%bon%\')\r\n                     then 8 else 0 end) + (case when\r\n                (wp_wd_posts.post_content LIKE \'%bon%\')\r\n                 then 8 else 0 end) + (case when\r\n                    (wp_wd_posts.post_excerpt LIKE \'%bon%\')\r\n                     then 7 else 0 end) + (case when\r\n                (wp_wd_posts.post_excerpt LIKE \'%bon%\')\r\n                 then 7 else 0 end)) as relevance\r\n    		FROM wp_wd_posts\r\n        \r\n        \r\n    	WHERE\r\n                (wp_wd_posts.post_type IN (\'post\',\'page\') )\r\n            AND ( wp_wd_posts.post_status = \'publish\')\r\n            AND (1)\r\n            AND (( wp_wd_posts.post_title LIKE \'%bon%\' ) OR ( wp_wd_posts.post_content LIKE \'%bon%\' ) OR ( wp_wd_posts.post_excerpt LIKE \'%bon%\' ))\r\n            AND (wp_wd_posts.ID NOT IN (-55))\r\n            AND ( (1) )\r\n        GROUP BY\r\n          wp_wd_posts.ID\r\n        ORDER BY\r\n        	relevance DESC, date DESC, id DESC\r\n        LIMIT 10";s:7:"results";i:2;}i:4;a:4:{s:6:"phrase";s:5:"hello";s:7:"options";a:16:{s:15:"qtranslate_lang";s:1:"0";s:11:"set_intitle";b:1;s:13:"set_incontent";b:1;s:13:"set_inexcerpt";b:1;s:11:"set_inposts";b:1;s:11:"set_inpages";b:1;s:11:"categoryset";a:1:{i:0;s:1:"1";}s:13:"set_exactonly";b:0;s:14:"set_incomments";b:0;s:13:"searchinterms";b:0;s:13:"set_inbpusers";b:0;s:14:"set_inbpgroups";b:0;s:14:"set_inbpforums";b:0;s:10:"maxresults";s:2:"10";s:8:"do_group";b:1;s:7:"termset";a:0:{}}s:5:"query";s:1756:"\r\n    		SELECT \r\n          wp_wd_posts.post_title as title,\r\n          wp_wd_posts.ID as id,\r\n          wp_wd_posts.post_date as date,               \r\n          wp_wd_posts.post_content as content,\r\n          \'\' as excerpt,\r\n          \'pagepost\' as content_type,\r\n	        (SELECT\r\n	            wp_wd_users.display_name as author\r\n	            FROM wp_wd_users\r\n	            WHERE wp_wd_users.ID = wp_wd_posts.post_author\r\n	        ) as author,\r\n          \'\' as ttid,\r\n          wp_wd_posts.post_type as post_type,\r\n          ((case when\r\n                (wp_wd_posts.post_title LIKE \'%hello%\')\r\n                 then 10 else 0 end) + (case when\r\n                  (wp_wd_posts.post_title LIKE \'%hello%\')\r\n                   then 10 else 0 end) + (case when\r\n                    (wp_wd_posts.post_content LIKE \'%hello%\')\r\n                     then 8 else 0 end) + (case when\r\n                (wp_wd_posts.post_content LIKE \'%hello%\')\r\n                 then 8 else 0 end) + (case when\r\n                    (wp_wd_posts.post_excerpt LIKE \'%hello%\')\r\n                     then 7 else 0 end) + (case when\r\n                (wp_wd_posts.post_excerpt LIKE \'%hello%\')\r\n                 then 7 else 0 end)) as relevance\r\n    		FROM wp_wd_posts\r\n        \r\n        \r\n    	WHERE\r\n                (wp_wd_posts.post_type IN (\'post\',\'page\') )\r\n            AND ( wp_wd_posts.post_status = \'publish\')\r\n            AND (1)\r\n            AND (( wp_wd_posts.post_title LIKE \'%hello%\' ) OR ( wp_wd_posts.post_content LIKE \'%hello%\' ) OR ( wp_wd_posts.post_excerpt LIKE \'%hello%\' ))\r\n            AND (wp_wd_posts.ID NOT IN (-55))\r\n            AND ( (1) )\r\n        GROUP BY\r\n          wp_wd_posts.ID\r\n        ORDER BY\r\n        	relevance DESC, date DESC, id DESC\r\n        LIMIT 10";s:7:"results";i:1;}}}', 'yes'),
(389, 'asl_options', 'a:134:{s:5:"theme";s:9:"underline";s:20:"override_search_form";s:1:"0";s:14:"triggeronclick";s:1:"1";s:23:"trigger_on_facet_change";s:1:"1";s:15:"redirectonclick";s:1:"0";s:17:"redirect_click_to";s:12:"results_page";s:17:"redirect_on_enter";s:1:"0";s:17:"redirect_enter_to";s:12:"results_page";s:13:"triggerontype";s:1:"1";s:13:"searchinposts";s:1:"1";s:13:"searchinpages";s:1:"1";s:11:"customtypes";s:0:"";s:13:"searchintitle";s:1:"1";s:15:"searchincontent";s:1:"1";s:15:"searchinexcerpt";s:1:"1";s:12:"customfields";s:0:"";s:24:"override_default_results";s:1:"0";s:9:"exactonly";s:1:"0";s:13:"searchinterms";s:1:"0";s:9:"charcount";s:1:"3";s:10:"maxresults";s:2:"10";s:10:"itemscount";s:1:"4";s:16:"resultitemheight";s:4:"70px";s:15:"orderby_primary";s:14:"relevance DESC";s:17:"orderby_secondary";s:9:"date DESC";s:11:"show_images";s:1:"1";s:18:"image_transparency";i:1;s:14:"image_bg_color";s:7:"#FFFFFF";s:11:"image_width";s:2:"70";s:12:"image_height";s:2:"70";s:19:"image_crop_location";s:1:"c";s:27:"image_crop_location_selects";a:9:{i:0;a:2:{s:6:"option";s:13:"In the center";s:5:"value";s:1:"c";}i:1;a:2:{s:6:"option";s:9:"Align top";s:5:"value";s:1:"t";}i:2;a:2:{s:6:"option";s:15:"Align top right";s:5:"value";s:2:"tr";}i:3;a:2:{s:6:"option";s:14:"Align top left";s:5:"value";s:2:"tl";}i:4;a:2:{s:6:"option";s:12:"Align bottom";s:5:"value";s:1:"b";}i:5;a:2:{s:6:"option";s:18:"Align bottom right";s:5:"value";s:2:"br";}i:6;a:2:{s:6:"option";s:17:"Align bottom left";s:5:"value";s:2:"bl";}i:7;a:2:{s:6:"option";s:10:"Align left";s:5:"value";s:1:"l";}i:8;a:2:{s:6:"option";s:11:"Align right";s:5:"value";s:1:"r";}}s:13:"image_sources";a:7:{i:0;a:2:{s:6:"option";s:14:"Featured image";s:5:"value";s:8:"featured";}i:1;a:2:{s:6:"option";s:12:"Post Content";s:5:"value";s:7:"content";}i:2;a:2:{s:6:"option";s:12:"Post Excerpt";s:5:"value";s:7:"excerpt";}i:3;a:2:{s:6:"option";s:12:"Custom field";s:5:"value";s:6:"custom";}i:4;a:2:{s:6:"option";s:15:"Page Screenshot";s:5:"value";s:10:"screenshot";}i:5;a:2:{s:6:"option";s:13:"Default image";s:5:"value";s:7:"default";}i:6;a:2:{s:6:"option";s:8:"Disabled";s:5:"value";s:8:"disabled";}}s:13:"image_source1";s:8:"featured";s:13:"image_source2";s:7:"content";s:13:"image_source3";s:7:"excerpt";s:13:"image_source4";s:6:"custom";s:13:"image_source5";s:7:"default";s:13:"image_default";s:87:"http://localhost:8888/blogwebdesign/wp-content/plugins/ajax-search-lite/img/default.jpg";s:18:"image_custom_field";s:0:"";s:12:"use_timthumb";i:1;s:29:"show_frontend_search_settings";s:1:"0";s:16:"showexactmatches";s:1:"1";s:17:"showsearchinposts";s:1:"0";s:17:"showsearchinpages";s:1:"0";s:17:"showsearchintitle";s:1:"1";s:19:"showsearchincontent";s:1:"0";s:15:"showcustomtypes";s:0:"";s:20:"showsearchincomments";i:1;s:19:"showsearchinexcerpt";i:1;s:19:"showsearchinbpusers";i:0;s:20:"showsearchinbpgroups";i:0;s:20:"showsearchinbpforums";i:0;s:16:"exactmatchestext";s:19:"Mot exact seulement";s:17:"searchinpoststext";s:15:"Search in posts";s:17:"searchinpagestext";s:15:"Search in pages";s:17:"searchintitletext";s:24:"Rechercher dans le titre";s:19:"searchincontenttext";s:17:"Search in content";s:20:"searchincommentstext";s:18:"Search in comments";s:19:"searchinexcerpttext";s:17:"Search in excerpt";s:19:"searchinbpuserstext";s:15:"Search in users";s:20:"searchinbpgroupstext";s:16:"Search in groups";s:20:"searchinbpforumstext";s:16:"Search in forums";s:22:"showsearchincategories";s:1:"1";s:17:"showuncategorised";s:1:"1";s:20:"exsearchincategories";s:0:"";s:26:"exsearchincategoriesheight";i:200;s:22:"showsearchintaxonomies";i:1;s:9:"showterms";s:0:"";s:23:"showseparatefilterboxes";i:1;s:24:"exsearchintaxonomiestext";s:9:"Filter by";s:24:"exsearchincategoriestext";s:20:"Filter by Categories";s:9:"box_width";s:4:"100%";s:10:"box_margin";s:22:"||0px||0px||0px||0px||";s:15:"resultstype_def";a:4:{i:0;a:2:{s:6:"option";s:16:"Vertical Results";s:5:"value";s:8:"vertical";}i:1;a:2:{s:6:"option";s:18:"Horizontal Results";s:5:"value";s:10:"horizontal";}i:2;a:2:{s:6:"option";s:16:"Isotopic Results";s:5:"value";s:8:"isotopic";}i:3;a:2:{s:6:"option";s:22:"Polaroid style Results";s:5:"value";s:8:"polaroid";}}s:11:"resultstype";s:8:"vertical";s:19:"resultsposition_def";a:2:{i:0;a:2:{s:6:"option";s:20:"Hover - over content";s:5:"value";s:5:"hover";}i:1;a:2:{s:6:"option";s:22:"Block - pushes content";s:5:"value";s:5:"block";}}s:15:"resultsposition";s:5:"hover";s:16:"resultsmargintop";s:4:"12px";s:17:"defaultsearchtext";s:24:"Faire une recherche ....";s:15:"showmoreresults";s:1:"0";s:19:"showmoreresultstext";s:22:"Plus de résultats ...";s:12:"showmorefont";s:151:"font-weight:normal;font-family:--g--Open Sans;color:rgba(5, 94, 148, 1);font-size:12px;line-height:15px;text-shadow:0px 0px 0px rgba(255, 255, 255, 0);";s:17:"scroll_to_results";s:1:"0";s:19:"resultareaclickable";s:1:"1";s:23:"close_on_document_click";s:1:"1";s:15:"show_close_icon";s:1:"1";s:10:"showauthor";s:1:"0";s:8:"showdate";s:1:"0";s:15:"showdescription";s:1:"1";s:17:"descriptionlength";s:3:"100";s:19:"description_context";s:1:"0";s:13:"noresultstext";s:11:"No results!";s:14:"didyoumeantext";s:13:"Did you mean:";s:12:"kw_highlight";s:1:"0";s:24:"kw_highlight_whole_words";s:1:"1";s:15:"highlight_color";s:20:"rgba(217, 49, 43, 1)";s:18:"highlight_bg_color";s:22:"rgba(238, 238, 238, 1)";s:12:"autocomplete";s:1:"1";s:14:"kw_suggestions";s:1:"1";s:9:"kw_length";s:2:"60";s:8:"kw_count";s:2:"10";s:14:"kw_google_lang";s:2:"en";s:13:"kw_exceptions";s:0:"";s:12:"shortcode_op";s:6:"remove";s:16:"striptagsexclude";s:0:"";s:12:"runshortcode";i:1;s:14:"stripshortcode";i:0;s:19:"pageswithcategories";i:0;s:14:"titlefield_def";a:2:{i:0;a:2:{s:6:"option";s:10:"Post Title";s:5:"value";i:0;}i:1;a:2:{s:6:"option";s:12:"Post Excerpt";s:5:"value";i:1;}}s:10:"titlefield";s:1:"0";s:20:"descriptionfield_def";a:3:{i:0;a:2:{s:6:"option";s:16:"Post Description";s:5:"value";i:0;}i:1;a:2:{s:6:"option";s:12:"Post Excerpt";s:5:"value";i:1;}i:2;a:2:{s:6:"option";s:10:"Post Title";s:5:"value";i:2;}}s:16:"descriptionfield";s:1:"0";s:17:"excludecategories";s:0:"";s:12:"excludeposts";s:0:"";s:16:"exclude_term_ids";s:0:"";s:18:"wpml_compatibility";s:1:"1";s:21:"classname-customtypes";s:23:"wpdreamsCustomPostTypes";s:22:"classname-customfields";s:20:"wpdreamsCustomFields";s:10:"asl_submit";s:1:"1";s:10:"submit_asl";s:13:"Save options!";s:25:"classname-showcustomtypes";s:31:"wpdreamsCustomPostTypesEditable";s:30:"classname-exsearchincategories";s:18:"wpdreamsCategories";s:7:"topleft";s:3:"0px";s:11:"bottomright";s:3:"0px";s:8:"topright";s:3:"0px";s:10:"bottomleft";s:3:"0px";s:27:"classname-excludecategories";s:18:"wpdreamsCategories";s:10:"sett_tabid";s:1:"3";s:20:"selected-customtypes";N;s:21:"selected-customfields";N;s:24:"selected-showcustomtypes";N;s:29:"selected-exsearchincategories";N;s:26:"selected-excludecategories";N;}', 'yes'),
(747, 'wpmembers_settings', 'a:19:{s:7:"version";s:5:"3.1.1";s:5:"block";a:2:{s:4:"post";i:1;s:4:"page";i:0;}s:12:"show_excerpt";a:2:{s:4:"post";i:0;s:4:"page";i:0;}s:8:"show_reg";a:2:{s:4:"post";i:1;s:4:"page";i:1;}s:10:"show_login";a:2:{s:4:"post";i:1;s:4:"page";i:1;}s:6:"autoex";a:2:{s:4:"post";a:2:{s:7:"enabled";i:0;s:6:"length";s:0:"";}s:4:"page";a:2:{s:7:"enabled";i:0;s:6:"length";s:0:"";}}s:6:"notify";i:0;s:7:"mod_reg";i:0;s:7:"captcha";i:0;s:7:"use_exp";i:0;s:9:"use_trial";i:0;s:8:"warnings";i:0;s:10:"user_pages";a:3:{s:7:"profile";s:0:"";s:8:"register";s:0:"";s:5:"login";s:0:"";}s:6:"cssurl";s:0:"";s:5:"style";s:90:"http://localhost:8888/blogwebdesign/wp-content/plugins/wp-members/css/generic-no-float.css";s:6:"attrib";i:0;s:10:"post_types";a:0:{}s:9:"form_tags";a:1:{s:7:"default";s:20:"Registration Default";}s:5:"email";a:2:{s:4:"from";s:0:"";s:9:"from_name";s:0:"";}}', 'yes'),
(748, 'wpmembers_fields', 'a:16:{i:0;a:7:{i:0;i:1;i:1;s:10:"First Name";i:2;s:10:"first_name";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"y";}i:1;a:7:{i:0;i:2;i:1;s:9:"Last Name";i:2;s:9:"last_name";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"y";}i:2;a:7:{i:0;i:3;i:1;s:9:"Address 1";i:2;s:5:"addr1";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:3;a:7:{i:0;i:4;i:1;s:9:"Address 2";i:2;s:5:"addr2";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"n";i:6;s:1:"n";}i:4;a:7:{i:0;i:5;i:1;s:4:"City";i:2;s:4:"city";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:5;a:7:{i:0;i:6;i:1;s:5:"State";i:2;s:8:"thestate";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:6;a:7:{i:0;i:7;i:1;s:3:"Zip";i:2;s:3:"zip";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:7;a:7:{i:0;i:8;i:1;s:7:"Country";i:2;s:7:"country";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:8;a:7:{i:0;i:9;i:1;s:9:"Day Phone";i:2;s:6:"phone1";i:3;s:4:"text";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"n";}i:9;a:7:{i:0;i:10;i:1;s:5:"Email";i:2;s:10:"user_email";i:3;s:5:"email";i:4;s:1:"y";i:5;s:1:"y";i:6;s:1:"y";}i:10;a:7:{i:0;i:11;i:1;s:13:"Confirm Email";i:2;s:13:"confirm_email";i:3;s:5:"email";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";}i:11;a:7:{i:0;i:12;i:1;s:7:"Website";i:2;s:8:"user_url";i:3;s:3:"url";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"y";}i:12;a:7:{i:0;i:13;i:1;s:17:"Biographical Info";i:2;s:11:"description";i:3;s:8:"textarea";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"y";}i:13;a:7:{i:0;i:14;i:1;s:8:"Password";i:2;s:8:"password";i:3;s:8:"password";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";}i:14;a:7:{i:0;i:15;i:1;s:16:"Confirm Password";i:2;s:16:"confirm_password";i:3;s:8:"password";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";}i:15;a:9:{i:0;i:16;i:1;s:3:"TOS";i:2;s:3:"tos";i:3;s:8:"checkbox";i:4;s:1:"n";i:5;s:1:"n";i:6;s:1:"n";i:7;s:5:"agree";i:8;s:1:"n";}}', 'yes'),
(749, 'wpmembers_tos', 'Put your TOS (Terms of Service) text here.  You can use HTML markup.', 'yes'),
(750, 'wpmembers_dialogs', 'a:9:{s:14:"restricted_msg";s:119:"This content is restricted to site members.  If you are an existing user, please log in.  New users may register below.";s:4:"user";s:50:"Sorry, that username is taken, please try another.";s:5:"email";s:74:"Sorry, that email address already has an account.<br />Please try another.";s:7:"success";s:124:"Congratulations! Your registration was successful.<br /><br />You may now log in using the password that was emailed to you.";s:11:"editsuccess";s:29:"Your information was updated!";s:11:"pwdchangerr";s:53:"Passwords did not match.<br /><br />Please try again.";s:16:"pwdchangesuccess";s:30:"Password successfully changed!";s:11:"pwdreseterr";s:65:"Either the username or email address do not exist in our records.";s:15:"pwdresetsuccess";s:135:"Password successfully reset!<br /><br />An email containing a new password has been sent to the email address on file for your account.";}', 'yes'),
(751, 'wpmembers_email_newreg', 'a:2:{s:4:"subj";s:37:"Your registration info for [blogname]";s:4:"body";s:268:"Thank you for registering for [blogname]\r\n\r\nYour registration information is below.\r\nYou may wish to retain a copy for your records.\r\n\r\nusername: [username]\r\npassword: [password]\r\n\r\nYou may login here:\r\n[reglink]\r\n\r\nYou may change your password here:\r\n[members-area]\r\n";}', 'no'),
(752, 'wpmembers_email_newmod', 'a:2:{s:4:"subj";s:40:"Thank you for registering for [blogname]";s:4:"body";s:173:"Thank you for registering for [blogname]. \r\nYour registration has been received and is pending approval.\r\nYou will receive login instructions upon approval of your account\r\n";}', 'no'),
(753, 'wpmembers_email_appmod', 'a:2:{s:4:"subj";s:50:"Your registration for [blogname] has been approved";s:4:"body";s:299:"Your registration for [blogname] has been approved.\r\n\r\nYour registration information is below.\r\nYou may wish to retain a copy for your records.\r\n\r\nusername: [username]\r\npassword: [password]\r\n\r\nYou may login and change your password here:\r\n[members-area]\r\n\r\nYou originally registered at:\r\n[reglink]\r\n";}', 'no'),
(754, 'wpmembers_email_repass', 'a:2:{s:4:"subj";s:34:"Your password reset for [blogname]";s:4:"body";s:157:"Your password for [blogname] has been reset\r\n\r\nYour new password is included below. You may wish to retain a copy for your records.\r\n\r\npassword: [password]\r\n";}', 'no'),
(755, 'wpmembers_email_notify', 'a:2:{s:4:"subj";s:36:"New user registration for [blogname]";s:4:"body";s:194:"The following user registered for [blogname]:\r\n\r\nusername: [username]\r\nemail: [email]\r\n\r\n[fields]\r\nThis user registered here:\r\n[reglink]\r\n\r\nuser IP: [user-ip]\r\n\r\nactivate user: [activate-user]\r\n";}', 'no'),
(756, 'wpmembers_email_footer', '----------------------------------\r\nThis is an automated message from [blogname]\r\nPlease do not reply to this address', 'no'),
(757, 'wpmembers_email_getuser', 'a:2:{s:4:"subj";s:23:"Username for [blogname]";s:4:"body";s:64:"Your username for [blogname] is below.\r\n\r\nusername: [username]\r\n";}', 'no'),
(758, 'wpmembers_style', 'http://localhost:8888/blogwebdesign/wp-content/plugins/wp-members/css/generic-no-float.css', 'yes'),
(760, 'widget_widget_wpmemwidget', 'a:1:{s:12:"_multiwidget";i:1;}', 'yes'),
(1040, 'category_children', 'a:1:{i:7;a:2:{i:0;i:8;i:1;i:9;}}', 'yes'),
(1056, 'wpseo_sitemap_attachment_cache_validator', '6ljgd', 'yes'),
(1123, '_wp_session_a3a5339ecd03bd7a546cb11cca26f7ba', 'a:0:{}', 'no'),
(1124, '_wp_session_expires_a3a5339ecd03bd7a546cb11cca26f7ba', '1464642045', 'no'),
(1136, '_wp_session_28c6118ff138552d2e7b3dbda34acc5b', 'a:0:{}', 'no'),
(1137, '_wp_session_expires_28c6118ff138552d2e7b3dbda34acc5b', '1464642351', 'no'),
(1155, '_wp_session_cbcbd12c95daeca57d9fa18e0da355f0', 'a:0:{}', 'no'),
(1156, '_wp_session_expires_cbcbd12c95daeca57d9fa18e0da355f0', '1464643268', 'no'),
(1176, '_wp_session_expires_629a9d3a9e87280fe34fa39fae512c84', '1464644388', 'no'),
(1189, '_wp_session_629a9d3a9e87280fe34fa39fae512c84', 'a:0:{}', 'no') ;

#
# End of data contents of table `wp_wd_options`
# --------------------------------------------------------



#
# Delete any existing table `wp_wd_postmeta`
#

DROP TABLE IF EXISTS `wp_wd_postmeta`;


#
# Table structure of table `wp_wd_postmeta`
#

CREATE TABLE `wp_wd_postmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `post_id` (`post_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wd_postmeta`
#
INSERT INTO `wp_wd_postmeta` ( `meta_id`, `post_id`, `meta_key`, `meta_value`) VALUES
(1, 2, '_wp_page_template', 'default'),
(2, 4, '_menu_item_type', 'custom'),
(3, 4, '_menu_item_menu_item_parent', '0'),
(4, 4, '_menu_item_object_id', '4'),
(5, 4, '_menu_item_object', 'custom'),
(6, 4, '_menu_item_target', ''),
(7, 4, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(8, 4, '_menu_item_xfn', ''),
(9, 4, '_menu_item_url', 'http://localhost:8888/blogwebdesign'),
(11, 5, '_edit_last', '1'),
(12, 5, '_edit_lock', '1456268999:1'),
(22, 9, '_edit_last', '1'),
(23, 9, '_edit_lock', '1456270743:1'),
(33, 14, '_edit_last', '1'),
(34, 14, '_edit_lock', '1456270874:1'),
(43, 18, '_edit_last', '1'),
(44, 18, '_edit_lock', '1464547062:1'),
(45, 18, '_yoast_wpseo_primary_astuces', ''),
(46, 20, '_menu_item_type', 'post_type_archive'),
(47, 20, '_menu_item_menu_item_parent', '0'),
(48, 20, '_menu_item_object_id', '0'),
(49, 20, '_menu_item_object', 'astuces'),
(50, 20, '_menu_item_target', ''),
(51, 20, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(52, 20, '_menu_item_xfn', ''),
(53, 20, '_menu_item_url', ''),
(55, 21, '_edit_last', '1'),
(56, 21, '_edit_lock', '1464640042:1'),
(59, 21, '_yoast_wpseo_primary_category', ''),
(60, 23, '_menu_item_type', 'custom'),
(61, 23, '_menu_item_menu_item_parent', '0'),
(62, 23, '_menu_item_object_id', '23'),
(63, 23, '_menu_item_object', 'custom'),
(64, 23, '_menu_item_target', ''),
(65, 23, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(66, 23, '_menu_item_xfn', ''),
(67, 23, '_menu_item_url', 'http://localhost:8888/blogwebdesign/'),
(69, 24, '_menu_item_type', 'post_type_archive'),
(70, 24, '_menu_item_menu_item_parent', '0'),
(71, 24, '_menu_item_object_id', '0'),
(72, 24, '_menu_item_object', 'astuces'),
(73, 24, '_menu_item_target', ''),
(74, 24, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(75, 24, '_menu_item_xfn', ''),
(76, 24, '_menu_item_url', ''),
(78, 25, '_menu_item_type', 'custom'),
(79, 25, '_menu_item_menu_item_parent', '0'),
(80, 25, '_menu_item_object_id', '25'),
(81, 25, '_menu_item_object', 'custom'),
(82, 25, '_menu_item_target', ''),
(83, 25, '_menu_item_classes', 'a:1:{i:0;s:0:"";}'),
(84, 25, '_menu_item_xfn', ''),
(85, 25, '_menu_item_url', '#'),
(87, 26, '_edit_last', '1'),
(88, 26, '_edit_lock', '1464558162:1'),
(89, 26, '_yoast_wpseo_primary_astuces', ''),
(90, 29, '_wp_attached_file', '2016/05/banniere.jpg'),
(91, 29, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1920;s:6:"height";i:1281;s:4:"file";s:20:"2016/05/banniere.jpg";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:20:"banniere-150x150.jpg";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:10:"image/jpeg";}s:6:"medium";a:4:{s:4:"file";s:20:"banniere-300x200.jpg";s:5:"width";i:300;s:6:"height";i:200;s:9:"mime-type";s:10:"image/jpeg";}s:12:"medium_large";a:4:{s:4:"file";s:20:"banniere-768x512.jpg";s:5:"width";i:768;s:6:"height";i:512;s:9:"mime-type";s:10:"image/jpeg";}s:5:"large";a:4:{s:4:"file";s:21:"banniere-1024x683.jpg";s:5:"width";i:1024;s:6:"height";i:683;s:9:"mime-type";s:10:"image/jpeg";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(92, 21, '_thumbnail_id', '29'),
(95, 1, '_edit_lock', '1464640246:1'),
(96, 30, '_wp_attached_file', '2016/02/cover.png'),
(97, 30, '_wp_attachment_metadata', 'a:5:{s:5:"width";i:1844;s:6:"height";i:792;s:4:"file";s:17:"2016/02/cover.png";s:5:"sizes";a:4:{s:9:"thumbnail";a:4:{s:4:"file";s:17:"cover-150x150.png";s:5:"width";i:150;s:6:"height";i:150;s:9:"mime-type";s:9:"image/png";}s:6:"medium";a:4:{s:4:"file";s:17:"cover-300x129.png";s:5:"width";i:300;s:6:"height";i:129;s:9:"mime-type";s:9:"image/png";}s:12:"medium_large";a:4:{s:4:"file";s:17:"cover-768x330.png";s:5:"width";i:768;s:6:"height";i:330;s:9:"mime-type";s:9:"image/png";}s:5:"large";a:4:{s:4:"file";s:18:"cover-1024x440.png";s:5:"width";i:1024;s:6:"height";i:440;s:9:"mime-type";s:9:"image/png";}}s:10:"image_meta";a:12:{s:8:"aperture";s:1:"0";s:6:"credit";s:0:"";s:6:"camera";s:0:"";s:7:"caption";s:0:"";s:17:"created_timestamp";s:1:"0";s:9:"copyright";s:0:"";s:12:"focal_length";s:1:"0";s:3:"iso";s:1:"0";s:13:"shutter_speed";s:1:"0";s:5:"title";s:0:"";s:11:"orientation";s:1:"0";s:8:"keywords";a:0:{}}}'),
(98, 1, '_thumbnail_id', '30'),
(99, 1, '_edit_last', '1'),
(102, 1, '_yoast_wpseo_primary_category', '') ;

#
# End of data contents of table `wp_wd_postmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_wd_posts`
#

DROP TABLE IF EXISTS `wp_wd_posts`;


#
# Table structure of table `wp_wd_posts`
#

CREATE TABLE `wp_wd_posts` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `post_author` bigint(20) unsigned NOT NULL DEFAULT '0',
  `post_date` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_date_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_title` text COLLATE utf8_unicode_ci NOT NULL,
  `post_excerpt` text COLLATE utf8_unicode_ci NOT NULL,
  `post_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'publish',
  `comment_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `ping_status` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'open',
  `post_password` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `post_name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `to_ping` text COLLATE utf8_unicode_ci NOT NULL,
  `pinged` text COLLATE utf8_unicode_ci NOT NULL,
  `post_modified` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_modified_gmt` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `post_content_filtered` longtext COLLATE utf8_unicode_ci NOT NULL,
  `post_parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `guid` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `menu_order` int(11) NOT NULL DEFAULT '0',
  `post_type` varchar(20) COLLATE utf8_unicode_ci NOT NULL DEFAULT 'post',
  `post_mime_type` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `comment_count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`ID`),
  KEY `post_name` (`post_name`(191)),
  KEY `type_status_date` (`post_type`,`post_status`,`post_date`,`ID`),
  KEY `post_parent` (`post_parent`),
  KEY `post_author` (`post_author`)
) ENGINE=InnoDB AUTO_INCREMENT=32 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wd_posts`
#
INSERT INTO `wp_wd_posts` ( `ID`, `post_author`, `post_date`, `post_date_gmt`, `post_content`, `post_title`, `post_excerpt`, `post_status`, `comment_status`, `ping_status`, `post_password`, `post_name`, `to_ping`, `pinged`, `post_modified`, `post_modified_gmt`, `post_content_filtered`, `post_parent`, `guid`, `menu_order`, `post_type`, `post_mime_type`, `comment_count`) VALUES
(1, 1, '2016-02-23 23:17:56', '2016-02-23 22:17:56', 'Bienvenue dans WordPress. Ceci est votre premier article. Modifiez-le ou supprimez-le, puis lancez-vous !', 'Bonjour tout le monde&nbsp;!', '', 'publish', 'open', 'open', '', 'bonjour-tout-le-monde', '', '', '2016-05-30 21:30:44', '2016-05-30 20:30:44', '', 0, 'http://localhost:8888/blogwebdesign/?p=1', 0, 'post', '', 1),
(2, 1, '2016-02-23 23:17:56', '2016-02-23 22:17:56', 'Voici un exemple de page. Elle est différente d\'un article de blog, en cela qu\'elle restera à la même place, et s\'affichera dans le menu de navigation de votre site (en fonction de votre thème). La plupart des gens commencent par écrire une page « À Propos » qui les présente aux visiteurs potentiels du site. Vous pourriez y écrire quelque chose de ce tenant :\n\n<blockquote>Bonjour ! Je suis un mécanicien qui aspire à devenir un acteur, et voici mon blog. J\'habite à Bordeaux, j\'ai un super chien baptisé Russell, et j\'aime la vodka-ananas (ainsi que regarder la pluie tomber).</blockquote>\n\n...ou bien quelque chose comme ça :\n\n<blockquote>La société 123 Machin Truc a été créée en 1971, et n\'a cessé de proposer au public des machins-trucs de qualité depuis lors. Située à Saint-Remy-en-Bouzemont-Saint-Genest-et-Isson, 123 Machin Truc emploie 2 000 personnes, et fabrique toutes sortes de bidules super pour la communauté bouzemontoise.</blockquote>\n\nÉtant donné que vous êtes un nouvel utilisateur de WordPress, vous devriez vous rendre sur votre <a href="http://localhost:8888/blogwebdesign/wp-admin/">tableau de bord</a> pour effacer la présente page, et créer de nouvelles pages avec votre propre contenu. Amusez-vous bien !', 'Page d&rsquo;exemple', '', 'publish', 'closed', 'open', '', 'page-d-exemple', '', '', '2016-02-23 23:17:56', '2016-02-23 22:17:56', '', 0, 'http://localhost:8888/blogwebdesign/?page_id=2', 0, 'page', '', 0),
(4, 1, '2016-02-23 23:24:09', '2016-02-23 22:24:09', '', 'Accueil', '', 'publish', 'closed', 'closed', '', 'accueil', '', '', '2016-05-29 19:40:29', '2016-05-29 18:40:29', '', 0, 'http://localhost:8888/blogwebdesign/?p=4', 1, 'nav_menu_item', '', 0),
(5, 1, '2016-02-24 00:08:33', '2016-02-23 23:08:33', 'Et ouiiii !!!!\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sagittis leo nisl, quis cursus tellus sodales vitae. Morbi efficitur mi justo, sed interdum eros tristique congue. Sed vehicula aliquet augue, sed aliquam lorem fermentum sit amet. Nulla a luctus velit, id finibus lacus. Nam risus est, mattis quis semper ac, pulvinar vel ex. Mauris tempor pellentesque feugiat. Praesent ut arcu varius magna dictum placerat sed pulvinar ex. Vivamus tristique nibh id fringilla commodo. Sed lectus mauris, rutrum at semper ac, consequat in diam. Nulla vel orci non nisl congue porta nec nec odio. Cras ut magna in quam placerat ornare. Nam molestie ut ex ut luctus. Ut maximus auctor odio, nec sollicitudin odio porttitor eget. Vestibulum diam tellus, tempor eu arcu venenatis, finibus tristique arcu. Curabitur ut efficitur tortor, sit amet faucibus enim.\r\n\r\nVestibulum elementum interdum eros, vel venenatis eros mollis et. Integer mattis dignissim dolor id pharetra. Curabitur tincidunt augue a lectus laoreet lacinia. Fusce mollis elementum aliquet. Integer ac quam at tortor tempor sodales. Nullam suscipit, urna vitae posuere laoreet, magna nisi efficitur purus, ac varius ligula dui eu felis. Donec consequat nibh quis tempus suscipit. Morbi in est in lectus vestibulum tempus eu at ligula. Donec ultrices gravida dolor vestibulum consequat. Aliquam eu tellus ultrices, facilisis augue eu, fermentum nunc. Morbi pulvinar dapibus ligula, ut mattis elit. Sed malesuada mollis tempor. In quis interdum ex.\r\n\r\nVestibulum rutrum maximus erat non suscipit. Fusce tincidunt, quam vitae ultrices suscipit, turpis massa vestibulum purus, pharetra ultricies nisi nisl vel enim. Aliquam tempor consectetur ornare. Ut semper feugiat erat sit amet finibus. Ut feugiat eros urna, nec laoreet neque sagittis eu. Vestibulum commodo, turpis a scelerisque dapibus, lacus urna cursus justo, eget convallis purus massa ut odio. Nulla mi risus, posuere id bibendum a, pulvinar nec enim. Maecenas rhoncus enim quis nunc vulputate, eget ultrices libero lacinia. Curabitur venenatis commodo mauris eu aliquam. Maecenas dapibus luctus quam ut porta. Pellentesque interdum, leo nec cursus porttitor, mi enim iaculis est, id eleifend dolor elit ac enim.\r\n\r\nNulla congue eget est vitae pretium. Integer eu leo nisi. Duis tincidunt nisl vitae orci mollis, non commodo nisl fringilla. Aliquam scelerisque ipsum turpis. Cras suscipit, augue a auctor sodales, tellus augue molestie neque, sit amet feugiat turpis sapien in purus. Phasellus interdum vehicula elit vel porta. Aenean tincidunt accumsan sapien, et accumsan metus. Morbi auctor velit at nisl sagittis, et auctor risus fermentum. Etiam eget mauris at ligula ultricies euismod. Aliquam at convallis diam. Suspendisse in fringilla libero. Curabitur tellus erat, ullamcorper ac purus in, laoreet malesuada magna.\r\n\r\nDonec aliquam dolor et justo tempor tincidunt. Sed nunc mi, maximus a pulvinar non, fermentum at purus. Sed mollis, justo blandit dapibus tincidunt, urna lacus fringilla justo, ut laoreet sapien orci quis nisi. Suspendisse mollis cursus velit, at vulputate metus sollicitudin vitae. Nunc eget augue nec neque dictum sodales. Donec imperdiet efficitur erat sit amet tincidunt. Integer ante ipsum, commodo eget mattis in, eleifend ullamcorper turpis. Donec pellentesque metus magna, vitae ultrices dui pulvinar at. Praesent maximus orci at nisi venenatis egestas. Nulla sed condimentum metus. Aliquam sed elit quis nulla finibus molestie. Nullam quis ultrices mauris.', 'Je suis une astuce', '', 'publish', 'open', 'closed', '', 'je-suis-une-astuce', '', '', '2016-02-24 00:11:33', '2016-02-23 23:11:33', '', 0, 'http://localhost:8888/blogwebdesign/?post_type=comics&#038;p=5', 0, 'comics', '', 0),
(6, 1, '2016-02-24 00:08:33', '2016-02-23 23:08:33', 'Et ouiiii !!!!', 'Je suis une astuce', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2016-02-24 00:08:33', '2016-02-23 23:08:33', '', 5, 'http://localhost:8888/blogwebdesign/2016/02/24/5-revision-v1/', 0, 'revision', '', 0),
(7, 1, '2016-02-24 00:11:33', '2016-02-23 23:11:33', 'Et ouiiii !!!!\r\n\r\nLorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sagittis leo nisl, quis cursus tellus sodales vitae. Morbi efficitur mi justo, sed interdum eros tristique congue. Sed vehicula aliquet augue, sed aliquam lorem fermentum sit amet. Nulla a luctus velit, id finibus lacus. Nam risus est, mattis quis semper ac, pulvinar vel ex. Mauris tempor pellentesque feugiat. Praesent ut arcu varius magna dictum placerat sed pulvinar ex. Vivamus tristique nibh id fringilla commodo. Sed lectus mauris, rutrum at semper ac, consequat in diam. Nulla vel orci non nisl congue porta nec nec odio. Cras ut magna in quam placerat ornare. Nam molestie ut ex ut luctus. Ut maximus auctor odio, nec sollicitudin odio porttitor eget. Vestibulum diam tellus, tempor eu arcu venenatis, finibus tristique arcu. Curabitur ut efficitur tortor, sit amet faucibus enim.\r\n\r\nVestibulum elementum interdum eros, vel venenatis eros mollis et. Integer mattis dignissim dolor id pharetra. Curabitur tincidunt augue a lectus laoreet lacinia. Fusce mollis elementum aliquet. Integer ac quam at tortor tempor sodales. Nullam suscipit, urna vitae posuere laoreet, magna nisi efficitur purus, ac varius ligula dui eu felis. Donec consequat nibh quis tempus suscipit. Morbi in est in lectus vestibulum tempus eu at ligula. Donec ultrices gravida dolor vestibulum consequat. Aliquam eu tellus ultrices, facilisis augue eu, fermentum nunc. Morbi pulvinar dapibus ligula, ut mattis elit. Sed malesuada mollis tempor. In quis interdum ex.\r\n\r\nVestibulum rutrum maximus erat non suscipit. Fusce tincidunt, quam vitae ultrices suscipit, turpis massa vestibulum purus, pharetra ultricies nisi nisl vel enim. Aliquam tempor consectetur ornare. Ut semper feugiat erat sit amet finibus. Ut feugiat eros urna, nec laoreet neque sagittis eu. Vestibulum commodo, turpis a scelerisque dapibus, lacus urna cursus justo, eget convallis purus massa ut odio. Nulla mi risus, posuere id bibendum a, pulvinar nec enim. Maecenas rhoncus enim quis nunc vulputate, eget ultrices libero lacinia. Curabitur venenatis commodo mauris eu aliquam. Maecenas dapibus luctus quam ut porta. Pellentesque interdum, leo nec cursus porttitor, mi enim iaculis est, id eleifend dolor elit ac enim.\r\n\r\nNulla congue eget est vitae pretium. Integer eu leo nisi. Duis tincidunt nisl vitae orci mollis, non commodo nisl fringilla. Aliquam scelerisque ipsum turpis. Cras suscipit, augue a auctor sodales, tellus augue molestie neque, sit amet feugiat turpis sapien in purus. Phasellus interdum vehicula elit vel porta. Aenean tincidunt accumsan sapien, et accumsan metus. Morbi auctor velit at nisl sagittis, et auctor risus fermentum. Etiam eget mauris at ligula ultricies euismod. Aliquam at convallis diam. Suspendisse in fringilla libero. Curabitur tellus erat, ullamcorper ac purus in, laoreet malesuada magna.\r\n\r\nDonec aliquam dolor et justo tempor tincidunt. Sed nunc mi, maximus a pulvinar non, fermentum at purus. Sed mollis, justo blandit dapibus tincidunt, urna lacus fringilla justo, ut laoreet sapien orci quis nisi. Suspendisse mollis cursus velit, at vulputate metus sollicitudin vitae. Nunc eget augue nec neque dictum sodales. Donec imperdiet efficitur erat sit amet tincidunt. Integer ante ipsum, commodo eget mattis in, eleifend ullamcorper turpis. Donec pellentesque metus magna, vitae ultrices dui pulvinar at. Praesent maximus orci at nisi venenatis egestas. Nulla sed condimentum metus. Aliquam sed elit quis nulla finibus molestie. Nullam quis ultrices mauris.', 'Je suis une astuce', '', 'inherit', 'closed', 'closed', '', '5-revision-v1', '', '', '2016-02-24 00:11:33', '2016-02-23 23:11:33', '', 5, 'http://localhost:8888/blogwebdesign/2016/02/24/5-revision-v1/', 0, 'revision', '', 0),
(9, 1, '2016-02-24 00:21:52', '2016-02-23 23:21:52', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sagittis leo nisl, quis cursus tellus sodales vitae. Morbi efficitur mi justo, sed interdum eros tristique congue. Sed vehicula aliquet augue, sed aliquam lorem fermentum sit amet. Nulla a luctus velit, id finibus lacus. Nam risus est, mattis quis semper ac, pulvinar vel ex. Mauris tempor pellentesque feugiat. Praesent ut arcu varius magna dictum placerat sed pulvinar ex. Vivamus tristique nibh id fringilla commodo. Sed lectus mauris, rutrum at semper ac, consequat in diam. Nulla vel orci non nisl congue porta nec nec odio. Cras ut magna in quam placerat ornare. Nam molestie ut ex ut luctus. Ut maximus auctor odio, nec sollicitudin odio porttitor eget. Vestibulum diam tellus, tempor eu arcu venenatis, finibus tristique arcu. Curabitur ut efficitur tortor, sit amet faucibus enim.\r\n\r\nVestibulum elementum interdum eros, vel venenatis eros mollis et. Integer mattis dignissim dolor id pharetra. Curabitur tincidunt augue a lectus laoreet lacinia. Fusce mollis elementum aliquet. Integer ac quam at tortor tempor sodales. Nullam suscipit, urna vitae posuere laoreet, magna nisi efficitur purus, ac varius ligula dui eu felis. Donec consequat nibh quis tempus suscipit. Morbi in est in lectus vestibulum tempus eu at ligula. Donec ultrices gravida dolor vestibulum consequat. Aliquam eu tellus ultrices, facilisis augue eu, fermentum nunc. Morbi pulvinar dapibus ligula, ut mattis elit. Sed malesuada mollis tempor. In quis interdum ex.\r\n\r\nVestibulum rutrum maximus erat non suscipit. Fusce tincidunt, quam vitae ultrices suscipit, turpis massa vestibulum purus, pharetra ultricies nisi nisl vel enim. Aliquam tempor consectetur ornare. Ut semper feugiat erat sit amet finibus. Ut feugiat eros urna, nec laoreet neque sagittis eu. Vestibulum commodo, turpis a scelerisque dapibus, lacus urna cursus justo, eget convallis purus massa ut odio. Nulla mi risus, posuere id bibendum a, pulvinar nec enim. Maecenas rhoncus enim quis nunc vulputate, eget ultrices libero lacinia. Curabitur venenatis commodo mauris eu aliquam. Maecenas dapibus luctus quam ut porta. Pellentesque interdum, leo nec cursus porttitor, mi enim iaculis est, id eleifend dolor elit ac enim.\r\n\r\nNulla congue eget est vitae pretium. Integer eu leo nisi. Duis tincidunt nisl vitae orci mollis, non commodo nisl fringilla. Aliquam scelerisque ipsum turpis. Cras suscipit, augue a auctor sodales, tellus augue molestie neque, sit amet feugiat turpis sapien in purus. Phasellus interdum vehicula elit vel porta. Aenean tincidunt accumsan sapien, et accumsan metus. Morbi auctor velit at nisl sagittis, et auctor risus fermentum. Etiam eget mauris at ligula ultricies euismod. Aliquam at convallis diam. Suspendisse in fringilla libero. Curabitur tellus erat, ullamcorper ac purus in, laoreet malesuada magna.\r\n\r\nDonec aliquam dolor et justo tempor tincidunt. Sed nunc mi, maximus a pulvinar non, fermentum at purus. Sed mollis, justo blandit dapibus tincidunt, urna lacus fringilla justo, ut laoreet sapien orci quis nisi. Suspendisse mollis cursus velit, at vulputate metus sollicitudin vitae. Nunc eget augue nec neque dictum sodales. Donec imperdiet efficitur erat sit amet tincidunt. Integer ante ipsum, commodo eget mattis in, eleifend ullamcorper turpis. Donec pellentesque metus magna, vitae ultrices dui pulvinar at. Praesent maximus orci at nisi venenatis egestas. Nulla sed condimentum metus. Aliquam sed elit quis nulla finibus molestie. Nullam quis ultrices mauris.', 'Une astuce', '', 'publish', 'open', 'closed', '', 'une-astuce', '', '', '2016-02-24 00:38:55', '2016-02-23 23:38:55', '', 0, 'http://localhost:8888/blogwebdesign/?post_type=astuces&#038;p=9', 0, 'astuces', '', 0),
(10, 1, '2016-02-24 00:21:52', '2016-02-23 23:21:52', 'Lorem ipsum dolor sit amet, consectetur adipiscing elit. Integer sagittis leo nisl, quis cursus tellus sodales vitae. Morbi efficitur mi justo, sed interdum eros tristique congue. Sed vehicula aliquet augue, sed aliquam lorem fermentum sit amet. Nulla a luctus velit, id finibus lacus. Nam risus est, mattis quis semper ac, pulvinar vel ex. Mauris tempor pellentesque feugiat. Praesent ut arcu varius magna dictum placerat sed pulvinar ex. Vivamus tristique nibh id fringilla commodo. Sed lectus mauris, rutrum at semper ac, consequat in diam. Nulla vel orci non nisl congue porta nec nec odio. Cras ut magna in quam placerat ornare. Nam molestie ut ex ut luctus. Ut maximus auctor odio, nec sollicitudin odio porttitor eget. Vestibulum diam tellus, tempor eu arcu venenatis, finibus tristique arcu. Curabitur ut efficitur tortor, sit amet faucibus enim.\r\n\r\nVestibulum elementum interdum eros, vel venenatis eros mollis et. Integer mattis dignissim dolor id pharetra. Curabitur tincidunt augue a lectus laoreet lacinia. Fusce mollis elementum aliquet. Integer ac quam at tortor tempor sodales. Nullam suscipit, urna vitae posuere laoreet, magna nisi efficitur purus, ac varius ligula dui eu felis. Donec consequat nibh quis tempus suscipit. Morbi in est in lectus vestibulum tempus eu at ligula. Donec ultrices gravida dolor vestibulum consequat. Aliquam eu tellus ultrices, facilisis augue eu, fermentum nunc. Morbi pulvinar dapibus ligula, ut mattis elit. Sed malesuada mollis tempor. In quis interdum ex.\r\n\r\nVestibulum rutrum maximus erat non suscipit. Fusce tincidunt, quam vitae ultrices suscipit, turpis massa vestibulum purus, pharetra ultricies nisi nisl vel enim. Aliquam tempor consectetur ornare. Ut semper feugiat erat sit amet finibus. Ut feugiat eros urna, nec laoreet neque sagittis eu. Vestibulum commodo, turpis a scelerisque dapibus, lacus urna cursus justo, eget convallis purus massa ut odio. Nulla mi risus, posuere id bibendum a, pulvinar nec enim. Maecenas rhoncus enim quis nunc vulputate, eget ultrices libero lacinia. Curabitur venenatis commodo mauris eu aliquam. Maecenas dapibus luctus quam ut porta. Pellentesque interdum, leo nec cursus porttitor, mi enim iaculis est, id eleifend dolor elit ac enim.\r\n\r\nNulla congue eget est vitae pretium. Integer eu leo nisi. Duis tincidunt nisl vitae orci mollis, non commodo nisl fringilla. Aliquam scelerisque ipsum turpis. Cras suscipit, augue a auctor sodales, tellus augue molestie neque, sit amet feugiat turpis sapien in purus. Phasellus interdum vehicula elit vel porta. Aenean tincidunt accumsan sapien, et accumsan metus. Morbi auctor velit at nisl sagittis, et auctor risus fermentum. Etiam eget mauris at ligula ultricies euismod. Aliquam at convallis diam. Suspendisse in fringilla libero. Curabitur tellus erat, ullamcorper ac purus in, laoreet malesuada magna.\r\n\r\nDonec aliquam dolor et justo tempor tincidunt. Sed nunc mi, maximus a pulvinar non, fermentum at purus. Sed mollis, justo blandit dapibus tincidunt, urna lacus fringilla justo, ut laoreet sapien orci quis nisi. Suspendisse mollis cursus velit, at vulputate metus sollicitudin vitae. Nunc eget augue nec neque dictum sodales. Donec imperdiet efficitur erat sit amet tincidunt. Integer ante ipsum, commodo eget mattis in, eleifend ullamcorper turpis. Donec pellentesque metus magna, vitae ultrices dui pulvinar at. Praesent maximus orci at nisi venenatis egestas. Nulla sed condimentum metus. Aliquam sed elit quis nulla finibus molestie. Nullam quis ultrices mauris.', 'Une astuce', '', 'inherit', 'closed', 'closed', '', '9-revision-v1', '', '', '2016-02-24 00:21:52', '2016-02-23 23:21:52', '', 9, 'http://localhost:8888/blogwebdesign/2016/02/24/9-revision-v1/', 0, 'revision', '', 0),
(14, 1, '2016-02-24 00:43:33', '2016-02-23 23:43:33', '<del>dezdpezfjprzfrùfazr frzafrf</del>', 'Je suis un article', '', 'publish', 'open', 'closed', '', 'je-suis-un-article', '', '', '2016-02-24 00:43:33', '2016-02-23 23:43:33', '', 0, 'http://localhost:8888/blogwebdesign/?post_type=design&#038;p=14', 0, 'design', '', 0),
(15, 1, '2016-02-24 00:43:33', '2016-02-23 23:43:33', '<del>dezdpezfjprzfrùfazr frzafrf</del>', 'Je suis un article', '', 'inherit', 'closed', 'closed', '', '14-revision-v1', '', '', '2016-02-24 00:43:33', '2016-02-23 23:43:33', '', 14, 'http://localhost:8888/blogwebdesign/14-revision-v1/', 0, 'revision', '', 0),
(17, 1, '2016-05-29 19:14:00', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-05-29 19:14:00', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/blogwebdesign/?p=17', 0, 'post', '', 0),
(18, 1, '2016-05-29 19:39:59', '2016-05-29 18:39:59', 'Hello astuce', 'Je suis une astuce', '', 'publish', 'open', 'closed', '', 'je-suis-une-astuce', '', '', '2016-05-29 19:39:59', '2016-05-29 18:39:59', '', 0, 'http://localhost:8888/blogwebdesign/?post_type=astuces&#038;p=18', 0, 'astuces', '', 0),
(19, 1, '2016-05-29 19:39:59', '2016-05-29 18:39:59', 'Hello astuce', 'Je suis une astuce', '', 'inherit', 'closed', 'closed', '', '18-revision-v1', '', '', '2016-05-29 19:39:59', '2016-05-29 18:39:59', '', 18, 'http://localhost:8888/blogwebdesign/18-revision-v1/', 0, 'revision', '', 0),
(20, 1, '2016-05-29 19:40:29', '2016-05-29 18:40:29', ' ', '', '', 'publish', 'closed', 'closed', '', '20', '', '', '2016-05-29 19:40:29', '2016-05-29 18:40:29', '', 0, 'http://localhost:8888/blogwebdesign/?p=20', 2, 'nav_menu_item', '', 0),
(21, 1, '2016-05-29 19:54:19', '2016-05-29 18:54:19', 'Hello !', 'Un autre article', '', 'publish', 'open', 'open', '', 'un-autre-article', '', '', '2016-05-30 21:13:34', '2016-05-30 20:13:34', '', 0, 'http://localhost:8888/blogwebdesign/?p=21', 0, 'post', '', 0),
(22, 1, '2016-05-29 19:54:19', '2016-05-29 18:54:19', 'Hello !', 'Un autre article', '', 'inherit', 'closed', 'closed', '', '21-revision-v1', '', '', '2016-05-29 19:54:19', '2016-05-29 18:54:19', '', 21, 'http://localhost:8888/blogwebdesign/21-revision-v1/', 0, 'revision', '', 0),
(23, 1, '2016-05-29 20:01:09', '2016-05-29 19:01:09', '', '<i class="fa fa-home" aria-hidden="true"></i>Accueil', '', 'publish', 'closed', 'closed', '', 'accueil-2', '', '', '2016-05-29 20:44:13', '2016-05-29 19:44:13', '', 0, 'http://localhost:8888/blogwebdesign/?p=23', 1, 'nav_menu_item', '', 0),
(24, 1, '2016-05-29 20:01:09', '2016-05-29 19:01:09', '', '<i class="fa fa-bolt" aria-hidden="true"></i>Astuces', '', 'publish', 'closed', 'closed', '', '24', '', '', '2016-05-29 20:44:13', '2016-05-29 19:44:13', '', 0, 'http://localhost:8888/blogwebdesign/?p=24', 2, 'nav_menu_item', '', 0),
(25, 1, '2016-05-29 20:40:59', '2016-05-29 19:40:59', '', '<i class="fa fa-code" aria-hidden="true"></i>Tuto code', '', 'publish', 'closed', 'closed', '', 'tuto-code', '', '', '2016-05-29 20:44:13', '2016-05-29 19:44:13', '', 0, 'http://localhost:8888/blogwebdesign/?p=25', 3, 'nav_menu_item', '', 0),
(26, 1, '2016-05-29 22:42:42', '2016-05-29 21:42:42', 'Hello', 'Un autre astuce', '', 'publish', 'open', 'closed', '', 'un-autre-astuce', '', '', '2016-05-29 22:42:42', '2016-05-29 21:42:42', '', 0, 'http://localhost:8888/blogwebdesign/?post_type=astuces&#038;p=26', 0, 'astuces', '', 0),
(27, 1, '2016-05-29 22:42:42', '2016-05-29 21:42:42', 'Hello', 'Un autre astuce', '', 'inherit', 'closed', 'closed', '', '26-revision-v1', '', '', '2016-05-29 22:42:42', '2016-05-29 21:42:42', '', 26, 'http://localhost:8888/blogwebdesign/26-revision-v1/', 0, 'revision', '', 0),
(28, 1, '2016-05-30 21:07:50', '0000-00-00 00:00:00', '', 'Brouillon auto', '', 'auto-draft', 'open', 'open', '', '', '', '', '2016-05-30 21:07:50', '0000-00-00 00:00:00', '', 0, 'http://localhost:8888/blogwebdesign/?p=28', 0, 'post', '', 0),
(29, 1, '2016-05-30 21:13:28', '2016-05-30 20:13:28', '', 'banniere', '', 'inherit', 'open', 'closed', '', 'banniere', '', '', '2016-05-30 21:13:28', '2016-05-30 20:13:28', '', 21, 'http://localhost:8888/blogwebdesign/wp-content/uploads/2016/05/banniere.jpg', 0, 'attachment', 'image/jpeg', 0),
(30, 1, '2016-05-30 21:30:36', '2016-05-30 20:30:36', '', 'cover', '', 'inherit', 'open', 'closed', '', 'cover', '', '', '2016-05-30 21:30:36', '2016-05-30 20:30:36', '', 1, 'http://localhost:8888/blogwebdesign/wp-content/uploads/2016/02/cover.png', 0, 'attachment', 'image/png', 0),
(31, 1, '2016-05-30 21:30:44', '2016-05-30 20:30:44', 'Bienvenue dans WordPress. Ceci est votre premier article. Modifiez-le ou supprimez-le, puis lancez-vous !', 'Bonjour tout le monde&nbsp;!', '', 'inherit', 'closed', 'closed', '', '1-revision-v1', '', '', '2016-05-30 21:30:44', '2016-05-30 20:30:44', '', 1, 'http://localhost:8888/blogwebdesign/1-revision-v1/', 0, 'revision', '', 0) ;

#
# End of data contents of table `wp_wd_posts`
# --------------------------------------------------------



#
# Delete any existing table `wp_wd_term_relationships`
#

DROP TABLE IF EXISTS `wp_wd_term_relationships`;


#
# Table structure of table `wp_wd_term_relationships`
#

CREATE TABLE `wp_wd_term_relationships` (
  `object_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_taxonomy_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `term_order` int(11) NOT NULL DEFAULT '0',
  PRIMARY KEY (`object_id`,`term_taxonomy_id`),
  KEY `term_taxonomy_id` (`term_taxonomy_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wd_term_relationships`
#
INSERT INTO `wp_wd_term_relationships` ( `object_id`, `term_taxonomy_id`, `term_order`) VALUES
(1, 1, 0),
(4, 2, 0),
(9, 3, 0),
(20, 2, 0),
(21, 1, 0),
(23, 5, 0),
(24, 5, 0),
(25, 5, 0) ;

#
# End of data contents of table `wp_wd_term_relationships`
# --------------------------------------------------------



#
# Delete any existing table `wp_wd_term_taxonomy`
#

DROP TABLE IF EXISTS `wp_wd_term_taxonomy`;


#
# Table structure of table `wp_wd_term_taxonomy`
#

CREATE TABLE `wp_wd_term_taxonomy` (
  `term_taxonomy_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `taxonomy` varchar(32) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `description` longtext COLLATE utf8_unicode_ci NOT NULL,
  `parent` bigint(20) unsigned NOT NULL DEFAULT '0',
  `count` bigint(20) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_taxonomy_id`),
  UNIQUE KEY `term_id_taxonomy` (`term_id`,`taxonomy`),
  KEY `taxonomy` (`taxonomy`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wd_term_taxonomy`
#
INSERT INTO `wp_wd_term_taxonomy` ( `term_taxonomy_id`, `term_id`, `taxonomy`, `description`, `parent`, `count`) VALUES
(1, 1, 'category', '', 0, 2),
(2, 2, 'nav_menu', '', 0, 2),
(3, 3, 'astuces', '', 0, 1),
(4, 4, 'astuces', '', 0, 0),
(5, 5, 'nav_menu', '', 0, 3),
(6, 6, 'category', '', 0, 0),
(7, 7, 'category', '', 0, 0),
(8, 8, 'category', '', 7, 0),
(9, 9, 'category', '', 7, 0) ;

#
# End of data contents of table `wp_wd_term_taxonomy`
# --------------------------------------------------------



#
# Delete any existing table `wp_wd_termmeta`
#

DROP TABLE IF EXISTS `wp_wd_termmeta`;


#
# Table structure of table `wp_wd_termmeta`
#

CREATE TABLE `wp_wd_termmeta` (
  `meta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `term_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`meta_id`),
  KEY `term_id` (`term_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wd_termmeta`
#

#
# End of data contents of table `wp_wd_termmeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_wd_terms`
#

DROP TABLE IF EXISTS `wp_wd_terms`;


#
# Table structure of table `wp_wd_terms`
#

CREATE TABLE `wp_wd_terms` (
  `term_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `slug` varchar(200) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `term_group` bigint(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`term_id`),
  KEY `slug` (`slug`(191)),
  KEY `name` (`name`(191))
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wd_terms`
#
INSERT INTO `wp_wd_terms` ( `term_id`, `name`, `slug`, `term_group`) VALUES
(1, 'Non classé', 'non-classe', 0),
(2, 'top', 'top', 0),
(3, 'html/css', 'htmlcss', 0),
(4, 'hardware', 'hardware', 0),
(5, 'Header menu', 'header-menu', 0),
(6, 'Webdesign', 'webdesign', 0),
(7, 'Développement', 'developpement', 0),
(8, 'HTML/CSS', 'htmlcss', 0),
(9, 'PHP', 'php', 0) ;

#
# End of data contents of table `wp_wd_terms`
# --------------------------------------------------------



#
# Delete any existing table `wp_wd_usermeta`
#

DROP TABLE IF EXISTS `wp_wd_usermeta`;


#
# Table structure of table `wp_wd_usermeta`
#

CREATE TABLE `wp_wd_usermeta` (
  `umeta_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned NOT NULL DEFAULT '0',
  `meta_key` varchar(255) COLLATE utf8_unicode_ci DEFAULT NULL,
  `meta_value` longtext COLLATE utf8_unicode_ci,
  PRIMARY KEY (`umeta_id`),
  KEY `user_id` (`user_id`),
  KEY `meta_key` (`meta_key`(191))
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wd_usermeta`
#
INSERT INTO `wp_wd_usermeta` ( `umeta_id`, `user_id`, `meta_key`, `meta_value`) VALUES
(1, 1, 'nickname', 'Alex'),
(2, 1, 'first_name', ''),
(3, 1, 'last_name', ''),
(4, 1, 'description', ''),
(5, 1, 'rich_editing', 'true'),
(6, 1, 'comment_shortcuts', 'false'),
(7, 1, 'admin_color', 'fresh'),
(8, 1, 'use_ssl', '0'),
(9, 1, 'show_admin_bar_front', 'false'),
(10, 1, 'wp_wd_capabilities', 'a:1:{s:13:"administrator";b:1;}'),
(11, 1, 'wp_wd_user_level', '10'),
(12, 1, 'dismissed_wp_pointers', ''),
(13, 1, 'show_welcome_panel', '1'),
(14, 1, 'session_tokens', 'a:1:{s:64:"91f34170866d38bfb2c26289f2d50180c1f51282908e64751e4e3b98fc082a40";a:4:{s:10:"expiration";i:1464718434;s:2:"ip";s:3:"::1";s:2:"ua";s:121:"Mozilla/5.0 (Macintosh; Intel Mac OS X 10_11_4) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/50.0.2661.102 Safari/537.36";s:5:"login";i:1464545634;}}'),
(15, 1, 'wp_wd_dashboard_quick_press_last_post_id', '17'),
(16, 1, 'managenav-menuscolumnshidden', 'a:5:{i:0;s:11:"link-target";i:1;s:11:"css-classes";i:2;s:3:"xfn";i:3;s:11:"description";i:4;s:15:"title-attribute";}'),
(17, 1, 'metaboxhidden_nav-menus', 'a:2:{i:0;s:12:"add-post_tag";i:1;s:15:"add-post_format";}'),
(18, 1, 'wpseo_ignore_tour', '1'),
(19, 1, 'nav_menu_recently_edited', '5'),
(20, 1, '_yoast_wpseo_profile_updated', '1464545725'),
(21, 1, 'wpseo_seen_about_version', '3.2.5'),
(22, 1, 'wp_wd_user-settings', 'libraryContent=browse'),
(23, 1, 'wp_wd_user-settings-time', '1464639210') ;

#
# End of data contents of table `wp_wd_usermeta`
# --------------------------------------------------------



#
# Delete any existing table `wp_wd_users`
#

DROP TABLE IF EXISTS `wp_wd_users`;


#
# Table structure of table `wp_wd_users`
#

CREATE TABLE `wp_wd_users` (
  `ID` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_login` varchar(60) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_pass` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_nicename` varchar(50) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_email` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_url` varchar(100) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_registered` datetime NOT NULL DEFAULT '0000-00-00 00:00:00',
  `user_activation_key` varchar(255) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  `user_status` int(11) NOT NULL DEFAULT '0',
  `display_name` varchar(250) COLLATE utf8_unicode_ci NOT NULL DEFAULT '',
  PRIMARY KEY (`ID`),
  KEY `user_login_key` (`user_login`),
  KEY `user_nicename` (`user_nicename`),
  KEY `user_email` (`user_email`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;


#
# Data contents of table `wp_wd_users`
#
INSERT INTO `wp_wd_users` ( `ID`, `user_login`, `user_pass`, `user_nicename`, `user_email`, `user_url`, `user_registered`, `user_activation_key`, `user_status`, `display_name`) VALUES
(1, 'Alex', '$P$BFy9q0qqCzbAGkKKbOBUvLS8fFafuT0', 'alex', 'alexandre.kong@gmail.com', '', '2016-02-23 22:17:56', '', 0, 'Alex') ;

#
# End of data contents of table `wp_wd_users`
# --------------------------------------------------------

#
# Add constraints back in and apply any alter data queries.
#

